package fr.pe.d12dal;

public class D12DAL
{
  public static final String D12DAL = "D12DAL";
  public static final String CREERDEMANDEINSTRUCTION = "CreerDemandeInstruction";
  public static final String LIRECOMPLETUDE = "LireCompletude";
  public static final String ENREGISTRERCOMPLETUDE = "EnregistrerCompletude";
  public static final String ENREGISTRERDEMANDEALLOCATION = "EnregistrerDemandeAllocation";
  public static final String LIRELISTEINFOSDAL = "LireListeInfosDal";
  public static final String ALIMENTERARBOPRESTATIONFINANCIERES = "AlimenterArboPrestationFinancieres";
  public static final String RECHERCHERDEMANDEPARMULTICRITERES = "RechercherDemandeParMultiCriteres";
  public static final String EDITERDEMANDEALLOCATION = "EditerDemandeAllocation";
  public static final String LIREDEMANDEALLOCATION = "LireDemandeAllocation";
  public static final String INITIALISERDALACDAOUACDB = "InitialiserDalACDAouACDB";
  public static final String LIRELISTEPIECESDEMANDE = "LireListePiecesDemande";
  public static final String ACTIVERDALNPDE = "ActiverDalNPDE";
  public static final String EXECUTERMADUWEB = "ExecuterMaduWeb";
  public static final String RECEPTIONFLUXGEDD52AUD = "ReceptionFluxGEDD52AUD";
  public static final String LIREDALCALI = "LireDALCALI";
  public static final String TRAITERFAUXPRIMO = "TraiterFauxPrimo";
  public static final String NOTIFIERABONNEMENT = "NotifierAbonnement";
  public static final String INITIALISERDEMANDE = "InitialiserDemande";
  public static final String LIRELISTESYNTHESEDALWEB = "LireListeSyntheseDalWeb";
  public static final String ENREGISTRERDALWEBBROUILLON = "EnregistrerDalWebBrouillon";
  public static final String LIREDALWEB = "LireDalWeb";
  public static final String SUPPRIMERDALWEBBROUILLON = "SupprimerDalWebBrouillon";
  public static final String LIREELIGIBILITE = "LireEligibilite";
  public static final String AJOUTERPIECEJUSTIFICATIVE = "AjouterPieceJustificative";
  public static final String REEXECUTERMADU = "ReexecuterMadu";
  public static final String LIRELISTEINFOAFFECTATIONDAL = "LireListeInfoAffectationDAL";
  public static final String SYNCHRONISERCOULEURDAL = "SynchroniserCouleurDAL";
}

/* Location:
 * Qualified Name:     D12DAL
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */