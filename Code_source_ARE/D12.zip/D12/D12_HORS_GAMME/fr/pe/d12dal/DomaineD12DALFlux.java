package fr.pe.d12dal;

public abstract interface DomaineD12DALFlux {}

/* Location:
 * Qualified Name:     DomaineD12DALFlux
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */