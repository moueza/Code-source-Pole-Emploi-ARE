package fr.pe.cali;

public abstract interface DomaineCaliServiceAsync {}

/* Location:
 * Qualified Name:     DomaineCaliServiceAsync
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */