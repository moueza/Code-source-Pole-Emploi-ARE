package fr.pe.cali;

public class FacadeDomaineCali
  extends FacadeDomaineCaliImplGen
{}

/* Location:
 * Qualified Name:     FacadeDomaineCali
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */