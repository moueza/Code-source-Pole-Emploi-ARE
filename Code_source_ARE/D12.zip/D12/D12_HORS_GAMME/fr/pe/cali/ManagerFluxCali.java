package fr.pe.cali;

import fr.pe.cali.client.AbstractManagerFluxCaliGen;

public class ManagerFluxCali
  extends AbstractManagerFluxCaliGen
{}

/* Location:
 * Qualified Name:     ManagerFluxCali
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */