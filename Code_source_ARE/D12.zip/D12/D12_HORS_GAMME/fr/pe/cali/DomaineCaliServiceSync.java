package fr.pe.cali;

public abstract interface DomaineCaliServiceSync {}

/* Location:
 * Qualified Name:     DomaineCaliServiceSync
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */