package fr.unedic.cali.dom;

public abstract interface OdSpec
  extends AttributionSpec
{}

/* Location:
 * Qualified Name:     OdSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */