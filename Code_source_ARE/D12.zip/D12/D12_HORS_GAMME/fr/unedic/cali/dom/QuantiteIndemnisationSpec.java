package fr.unedic.cali.dom;

public abstract interface QuantiteIndemnisationSpec
  extends QuantiteDroitSpec
{
  public abstract String getCodeFormuleMontant();
  
  public abstract void setCodeFormuleMontant(String paramString);
}

/* Location:
 * Qualified Name:     QuantiteIndemnisationSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */