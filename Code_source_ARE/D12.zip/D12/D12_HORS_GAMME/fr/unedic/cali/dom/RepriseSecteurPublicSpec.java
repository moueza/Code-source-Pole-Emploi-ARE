package fr.unedic.cali.dom;

public abstract interface RepriseSecteurPublicSpec
  extends DecisionSpec
{}

/* Location:
 * Qualified Name:     RepriseSecteurPublicSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */