package fr.unedic.cali.dom;

import fr.unedic.cali.dom.gen.CapitalIndemnisationAbstraitGen;
import fr.unedic.transverse.dom.spec.DomPCSpec;

public abstract class CapitalIndemnisationAbstrait
  extends CapitalIndemnisationAbstraitGen
{
  public CapitalIndemnisationAbstrait() {}
  
  public CapitalIndemnisationAbstrait(DomPCSpec p_pc)
  {
    super(p_pc);
  }
}

/* Location:
 * Qualified Name:     CapitalIndemnisationAbstrait
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */