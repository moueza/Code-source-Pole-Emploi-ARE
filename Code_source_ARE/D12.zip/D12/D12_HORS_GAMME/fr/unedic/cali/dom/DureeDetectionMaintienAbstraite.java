package fr.unedic.cali.dom;

import fr.unedic.cali.dom.gen.DureeDetectionMaintienAbstraiteGen;
import fr.unedic.transverse.dom.spec.DomPCSpec;

public abstract class DureeDetectionMaintienAbstraite
  extends DureeDetectionMaintienAbstraiteGen
{
  public DureeDetectionMaintienAbstraite() {}
  
  public DureeDetectionMaintienAbstraite(DomPCSpec p_pc)
  {
    super(p_pc);
  }
}

/* Location:
 * Qualified Name:     DureeDetectionMaintienAbstraite
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */