package fr.unedic.cali.dom;

import fr.unedic.util.ObjetMetierSpec;

public abstract interface SalaireReferenceSpec
  extends ObjetMetierSpec
{}

/* Location:
 * Qualified Name:     SalaireReferenceSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */