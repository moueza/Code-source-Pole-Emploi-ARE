package fr.unedic.cali.dom;

import fr.unedic.cali.utilitaire.filtres.FiltreCaliSpec;

public abstract interface EvenementReferenceExamenFiltrageDecisionSpec
{
  public abstract FiltreCaliSpec getFiltreRechercheDecisionDuMemeType();
}

/* Location:
 * Qualified Name:     EvenementReferenceExamenFiltrageDecisionSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */