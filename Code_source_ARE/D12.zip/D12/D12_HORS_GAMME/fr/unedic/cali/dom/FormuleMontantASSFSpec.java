package fr.unedic.cali.dom;

public abstract interface FormuleMontantASSFSpec {}

/* Location:
 * Qualified Name:     FormuleMontantASSFSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */