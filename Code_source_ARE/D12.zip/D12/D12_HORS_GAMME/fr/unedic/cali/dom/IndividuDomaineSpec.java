package fr.unedic.cali.dom;

public abstract interface IndividuDomaineSpec
{
  public abstract IndividuIdSpec getIndividuId();
  
  public abstract void setIndividuId(IndividuIdSpec paramIndividuIdSpec);
}

/* Location:
 * Qualified Name:     IndividuDomaineSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */