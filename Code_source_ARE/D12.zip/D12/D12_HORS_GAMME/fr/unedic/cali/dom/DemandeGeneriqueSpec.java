package fr.unedic.cali.dom;

public abstract interface DemandeGeneriqueSpec {}

/* Location:
 * Qualified Name:     DemandeGeneriqueSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */