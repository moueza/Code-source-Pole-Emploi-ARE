package fr.unedic.cali.dom;

public abstract interface OdAssuranceSpec
  extends OdSpec, AttributionAssuranceSpec
{}

/* Location:
 * Qualified Name:     OdAssuranceSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */