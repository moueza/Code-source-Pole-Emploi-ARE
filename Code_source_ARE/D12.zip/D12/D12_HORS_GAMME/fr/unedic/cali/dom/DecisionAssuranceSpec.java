package fr.unedic.cali.dom;

public abstract interface DecisionAssuranceSpec
  extends DecisionSpec
{
  public abstract int getCompetenceAdministrative();
  
  public abstract int getCompetenceFinanciere();
}

/* Location:
 * Qualified Name:     DecisionAssuranceSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */