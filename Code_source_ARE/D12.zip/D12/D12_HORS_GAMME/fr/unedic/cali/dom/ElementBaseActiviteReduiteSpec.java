package fr.unedic.cali.dom;

import fr.unedic.util.ObjetMetierSpec;

public abstract interface ElementBaseActiviteReduiteSpec
  extends ObjetMetierSpec
{}

/* Location:
 * Qualified Name:     ElementBaseActiviteReduiteSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */