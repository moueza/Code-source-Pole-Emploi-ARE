package fr.unedic.cali.dom;

public abstract interface ConstitutionDroitSpec
  extends ObjetPersistantSpec
{}

/* Location:
 * Qualified Name:     ConstitutionDroitSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */