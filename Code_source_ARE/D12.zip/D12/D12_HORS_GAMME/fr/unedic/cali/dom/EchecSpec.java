package fr.unedic.cali.dom;

public abstract interface EchecSpec
  extends RejetSpec
{
  public abstract OdSpec getOuvertureDroit();
}

/* Location:
 * Qualified Name:     EchecSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */