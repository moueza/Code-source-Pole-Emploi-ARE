package fr.unedic.cali.dom;

public abstract interface ReadmissionSpec
  extends OdSpec
{}

/* Location:
 * Qualified Name:     ReadmissionSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */