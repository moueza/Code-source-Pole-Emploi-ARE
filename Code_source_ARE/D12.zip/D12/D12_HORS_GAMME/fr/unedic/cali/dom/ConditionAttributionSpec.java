package fr.unedic.cali.dom;

public abstract interface ConditionAttributionSpec
  extends ElementDroitSpec
{
  public static final int SATISFAIT = 0;
  public static final int NON_SATISFAIT = 1;
  public static final int SANS_OBJET = 2;
}

/* Location:
 * Qualified Name:     ConditionAttributionSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */