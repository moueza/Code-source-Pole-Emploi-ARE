package fr.unedic.cali.dom;

import fr.unedic.util.temps.Temporel;

public abstract interface FaitGenerateurExamenSpec
  extends Temporel
{}

/* Location:
 * Qualified Name:     FaitGenerateurExamenSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */