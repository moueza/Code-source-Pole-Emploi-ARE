package fr.unedic.cali.dom;

public abstract interface EvenementReferenceExamenAntecedentSpec
  extends EvenementReferenceExamenSpec
{
  public abstract boolean verifierPremiereDemandeIndividu(DemandeSpec paramDemandeSpec);
}

/* Location:
 * Qualified Name:     EvenementReferenceExamenAntecedentSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */