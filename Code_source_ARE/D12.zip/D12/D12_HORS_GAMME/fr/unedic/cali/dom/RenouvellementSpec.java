package fr.unedic.cali.dom;

public abstract interface RenouvellementSpec
  extends AttributionSpec
{}

/* Location:
 * Qualified Name:     RenouvellementSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */