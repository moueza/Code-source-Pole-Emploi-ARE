package fr.unedic.cali.dom;

public abstract interface NovationSpec
  extends AttributionAssuranceSpec
{}

/* Location:
 * Qualified Name:     NovationSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */