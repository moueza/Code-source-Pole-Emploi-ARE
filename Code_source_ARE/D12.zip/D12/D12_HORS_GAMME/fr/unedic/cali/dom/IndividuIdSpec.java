package fr.unedic.cali.dom;

public abstract interface IndividuIdSpec
{
  public abstract IndividuSpec getIndividu();
  
  public abstract void setIndividu(IndividuSpec paramIndividuSpec);
  
  public abstract String getId();
}

/* Location:
 * Qualified Name:     IndividuIdSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */