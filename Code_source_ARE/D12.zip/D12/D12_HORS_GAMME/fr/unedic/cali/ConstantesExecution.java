package fr.unedic.cali;

public class ConstantesExecution
{
  public static final int CONTEXTE_EXECUTION_NORMAL = 0;
  public static final int CONTEXTE_EXECUTION_MIGRATION = 1;
  public static final String CONTEXTE_EXECUTION_INDIVIDU_PBJC_NCP_BATCH_SIGMA_MANDATEMENT_AUTO = "A";
  public static final String CONTEXTE_EXECUTION_INDIVIDU_PBJC_NCP_BATCH_SIGMA_MANDATEMENT_MANU = "B";
  public static final String CONTEXTE_EXECUTION_INDIVIDU_PBJC_NCP_BATCH_MANDATEMENT_AUTO = "1";
  public static final String CONTEXTE_EXECUTION_INDIVIDU_PBJC_NCP_BATCH_MANDATEMENT_MANU = "2";
  public static final String CONTEXTE_EXECUTION_INDIVIDU_PBJC_NCP_BATCH_MANDATEMENT_MANU_SPECTACLE_A8A10 = "4";
  public static final String CONTEXTE_EXECUTION_INDIVIDU_PBJC_NCP_TP = " ";
}

/* Location:
 * Qualified Name:     ConstantesExecution
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */