package fr.unedic.cali;

public class Attentes
{
  public static final String ATTENTE_AMFEDNJ_POUR_DNJ_AU_DELA_60_JOURS = "1";
  public static final String ATTENTE_AMFELIM_NOMBRE_MAX_FCT_ATTEINT = "2";
}

/* Location:
 * Qualified Name:     Attentes
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */