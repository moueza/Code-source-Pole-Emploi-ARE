package fr.unedic.cali.util;

public class ObjetUtilisateur
{
  private Object m_donneesUtilisateur;
  
  public Object getDonneesUtilisateur()
  {
    return m_donneesUtilisateur;
  }
  
  public void setDonneesUtilisateur(Object p_donneesUtilisateur)
  {
    m_donneesUtilisateur = p_donneesUtilisateur;
  }
}

/* Location:
 * Qualified Name:     ObjetUtilisateur
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */