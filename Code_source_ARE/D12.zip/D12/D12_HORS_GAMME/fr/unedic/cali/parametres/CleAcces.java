package fr.unedic.cali.parametres;

abstract interface CleAcces {}

/* Location:
 * Qualified Name:     CleAcces
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */