package fr.unedic.cali.parametres;

import fr.unedic.util.temps.Damj;

public class ConstantesStrategies
{
  public static final Damj DATE_2010SI2_DATE_PIVOT_CALCUL_ACTIVITE_REDUITE_AFF = new Damj(2010, 1, 1);
  public static final Damj DATE_2010SI2_DATE_PIVOT_COMPLEMENTAIRE_CALCUL_ACTIVITE_REDUITE_AFF = new Damj(2010, 7, 1);
}

/* Location:
 * Qualified Name:     ConstantesStrategies
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */