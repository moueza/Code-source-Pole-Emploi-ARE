package fr.unedic.cali.cons;

import java.math.BigDecimal;

public class ConstantesRevalorisationSalaire
{
  public static final int NB_MOIS_ANTERIORITE_DATE_PRC_VS_DATE_REVAL = 6;
  public static final BigDecimal INIT_REVAL_A_APPLIQUER = new BigDecimal("1");
  public static final BigDecimal COEFF_CENT_POURCENTS = new BigDecimal("1");
  public static final String STR_NB_JOURS_PAR_AN = "365";
  public static final String STR_NB_MOIS_PAR_AN = "12";
}

/* Location:
 * Qualified Name:     ConstantesRevalorisationSalaire
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */