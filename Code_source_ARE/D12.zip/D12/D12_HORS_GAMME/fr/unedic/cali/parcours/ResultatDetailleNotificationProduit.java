package fr.unedic.cali.parcours;

public class ResultatDetailleNotificationProduit
  extends ResultatDetailleProduit
{}

/* Location:
 * Qualified Name:     ResultatDetailleNotificationProduit
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */