package fr.unedic.cali.parcours;

import fr.unedic.util.services.Contexte;
import fr.unedic.util.services.ContexteException;

public class ParcoursAvantPilotageElementsIndemnisation
  extends ParcoursAvantPilotage
{
  public void controlerContexte(Contexte p_contexte)
    throws ContexteException
  {
    super.controlerContexte(p_contexte);
  }
}

/* Location:
 * Qualified Name:     ParcoursAvantPilotageElementsIndemnisation
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */