package fr.unedic.cali.parcours;

public abstract interface ResultatContexteExamenSpec
{
  public static final int NON_ANTERIORITE = 1;
  public static final int ANTERIORITE_ASS_CG = 2;
  public static final int ANTERIORITE_ASS_CPA = 3;
  public static final int ANTERIORITE_ASS_CG_SANS_FG = 4;
  public static final int RENOUVELLEMENT = 5;
  public static final int REMISE_EN_COURS = 6;
}

/* Location:
 * Qualified Name:     ResultatContexteExamenSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */