package fr.unedic.cali.parcours;

public abstract interface ParcoursPopulationSpec
  extends ParcoursService
{}

/* Location:
 * Qualified Name:     ParcoursPopulationSpec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */