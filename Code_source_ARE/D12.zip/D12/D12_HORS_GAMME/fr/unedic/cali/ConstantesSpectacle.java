package fr.unedic.cali;

public final class ConstantesSpectacle
{
  public static final String DECALAGE = "DECALAGE";
  public static final String PLAFOND = "PLAFOND";
  public static final String DELAI_ATTENTE = "DA";
  public static final String FRANCHISE_CP = "FCP";
  public static final String FRANCHISE_CP_RELIQUAT = "FCPR";
  public static final String FRANCHISE_SALAIRE = "FS";
  public static final String FRANCHISE_SALAIRE_RELIQUAT = "FSR";
}

/* Location:
 * Qualified Name:     ConstantesSpectacle
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */