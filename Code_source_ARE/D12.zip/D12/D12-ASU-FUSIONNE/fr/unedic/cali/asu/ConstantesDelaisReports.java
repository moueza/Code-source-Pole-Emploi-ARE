package fr.unedic.cali.asu;

public class ConstantesDelaisReports
{
  public static final String TYPE_PMC_NON_INDEMNISABLE = "PMC_NI";
  public static final String TYPE_PMC_INDEMNISABLE = "PMC_I";
  public static final String TYPE_DIFFERE_ICCP = "ICCP";
  public static final String TYPE_DIFFERE_ISLR = "ISLR";
  public static final String TYPE_DELAI_ATTENTE = "Différé";
  public static final String TYPE_PREAVIS_LEGAL = "PREAVIS_LEGAL";
  public static final int TYPE_PMC_NI = 1;
  public static final int TYPE_PMC_I = 2;
}

/* Location:
 * Qualified Name:     ConstantesDelaisReports
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */