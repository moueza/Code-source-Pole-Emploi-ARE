package fr.unedic.cali.asu;

public class ConstantesCarence
{
  public static final String TYPE_ISLR = "ISLR";
  public static final String TYPE_ICCP = "ICCP";
  public static final String TYPE_PMC_NON_INDEMNISABLE = "PMC_NI";
  public static final String TYPE_PMC_INDEMNISABLE = "PMC_I";
  public static final String TYPE_DIFFERE = "Différé";
  public static final String TYPE_PREAVIS_LEGAL = "PREAVIS_LEGAL";
  public static final String TYPE_FRANCHISE_CP = "FRANCHISE_CP";
  public static final String TYPE_FRANCHISE_SALAIRE = "FRANCHISE_SALAIRE";
  public static final int TYPE_PMC_NI = 1;
  public static final int TYPE_PMC_I = 2;
}

/* Location:
 * Qualified Name:     ConstantesCarence
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */