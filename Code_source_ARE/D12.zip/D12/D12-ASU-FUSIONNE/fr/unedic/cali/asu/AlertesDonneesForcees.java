package fr.unedic.cali.asu;

public class AlertesDonneesForcees
{
  public static final String ERR_FCT_FORCEE_AVANT_FGD = "ASU_PR_L_CALI_FCT_FORCEE_AVANT_FGD";
  public static final String LIB_FCT_FORCEE_AVANT_FGD = "La FCT forcée doit être antérieure au fait générateur.";
}

/* Location:
 * Qualified Name:     AlertesDonneesForcees
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */