package fr.unedic.cali.asu;

import fr.unedic.archi.logique.exception.ApplicativeException;
import fr.unedic.cali.affectation.parametres.AccesDecorReglementaire;
import fr.unedic.cali.affectation.parametres.CriteresQualification;
import fr.unedic.cali.asu.calcul.outilsfonctionnels.DefinitionStatutUtTraitementActiviteReduite;
import fr.unedic.cali.asu.calcul.outilsfonctionnels.RecuperationResultatMigrationCalcul;
import fr.unedic.cali.asu.dom.ConditionsAttributionSpec;
import fr.unedic.cali.asu.dom.Demande;
import fr.unedic.cali.asu.dom.DemandeAssuranceSpec;
import fr.unedic.cali.asu.dom.DonneesDemandeAssociee;
import fr.unedic.cali.asu.dom.DonneesTemporaires;
import fr.unedic.cali.asu.dom.DossierAffectation;
import fr.unedic.cali.asu.dom.DossierExamenAssuranceSpec;
import fr.unedic.cali.asu.dom.FaitGenerateurSpec;
import fr.unedic.cali.asu.dom.FormulaireAsu;
import fr.unedic.cali.asu.dom.FormulaireAsuTemporaire;
import fr.unedic.cali.asu.dom.OdAssuranceSpec;
import fr.unedic.cali.asu.fabriques.FabriqueParcoursLiquidationDemandeAsu;
import fr.unedic.cali.asu.liquidation.outilsfonctionnels.OutilConstructionDonneesEntreesRecuperationMontant;
import fr.unedic.cali.asu.mnt.dom.Accord;
import fr.unedic.cali.asu.mnt.dom.DemandeMaintien;
import fr.unedic.cali.asu.occasionnel.FabriqueExecutionPopulation;
import fr.unedic.cali.asu.occasionnel.FabriqueTraitementPopulation;
import fr.unedic.cali.asu.outilsfonctionnels.AlimentationBasePivot;
import fr.unedic.cali.asu.outilsfonctionnels.AlimenterBaseEchanges;
import fr.unedic.cali.asu.outilsfonctionnels.CREM;
import fr.unedic.cali.asu.outilsfonctionnels.ConstitutionEvenementReferenceExamen;
import fr.unedic.cali.asu.outilsfonctionnels.ControleAnnulerReexamen;
import fr.unedic.cali.asu.outilsfonctionnels.ControlePrescription;
import fr.unedic.cali.asu.outilsfonctionnels.GestionnaireErreur;
import fr.unedic.cali.asu.outilsfonctionnels.OutilAsp;
import fr.unedic.cali.asu.outilsfonctionnels.OutilDemandeASS;
import fr.unedic.cali.asu.outilsfonctionnels.OutilSimulationAffiliation;
import fr.unedic.cali.asu.outilsfonctionnels.OutilVerificationPresenceRevision;
import fr.unedic.cali.asu.outilsfonctionnels.OutilVerificationPresenceRevisionOD;
import fr.unedic.cali.asu.outilsfonctionnels.RechercherDemandeMaintien;
import fr.unedic.cali.asu.outilsfonctionnels.filtre.FiltreAttributionGammeAsuProduit;
import fr.unedic.cali.asu.outilsfonctionnels.liquidationauto.OutilFonctionnelTraitementsErreurs;
import fr.unedic.cali.asu.parametres.AccesAllocationMinimale;
import fr.unedic.cali.asu.parametres.AccesAllocationMinimaleMayotte;
import fr.unedic.cali.asu.parametres.AccesCotisationRetraiteComplementaire;
import fr.unedic.cali.asu.parametres.AccesPartieFixe;
import fr.unedic.cali.asu.parametres.AccesPlafond;
import fr.unedic.cali.asu.parametres.AccesPlafondMayotte;
import fr.unedic.cali.asu.parametres.AccesRevalorisationSjr;
import fr.unedic.cali.asu.parametres.AccesRevalorisationSjrMayotte;
import fr.unedic.cali.asu.parametres.AccesSalaireForfaitaireJournalierCategorieA2B;
import fr.unedic.cali.asu.parametres.AccesSeuilMinimalAREF;
import fr.unedic.cali.asu.parametres.AccesSeuilMinimalAREFM;
import fr.unedic.cali.asu.parametres.EvenementCategorieA2B;
import fr.unedic.cali.asu.parametres.EvenementParametre;
import fr.unedic.cali.asu.parametres.ParametresIndemnisation;
import fr.unedic.cali.asu.parcours.CreerDemandePrestation;
import fr.unedic.cali.asu.parcours.DomExamenAuFilEau;
import fr.unedic.cali.asu.parcours.DomLiquidationAssurance;
import fr.unedic.cali.asu.parcours.FabriquerFormulairesCali;
import fr.unedic.cali.asu.parcours.ParcoursExamenFilEau;
import fr.unedic.cali.asu.produits.liquidation.dom.spec.FinancementSpec;
import fr.unedic.cali.asu.produits.liquidation.outilsfonctionnels.ConstructionChronologie;
import fr.unedic.cali.asu.produits.liquidation.outilsfonctionnels.DelaiRecherche;
import fr.unedic.cali.autresdoms.cohab.dom.DonneesAuDJIMigration;
import fr.unedic.cali.autresdoms.ga.dom.spec.TravailSpec;
import fr.unedic.cali.calcul.FacadeCalculProduitSpec;
import fr.unedic.cali.calcul.dom.ArretProduitAvecRaison;
import fr.unedic.cali.calcul.dom.UniteTraitement;
import fr.unedic.cali.dom.AttributionSpec;
import fr.unedic.cali.dom.ClassementAdministratif;
import fr.unedic.cali.dom.ComportementExamenFilEauSpec;
import fr.unedic.cali.dom.ConteneurAccesDecorReglementaire;
import fr.unedic.cali.dom.DomSimulationAffiliation;
import fr.unedic.cali.dom.DossierAffectationSpec;
import fr.unedic.cali.dom.EvenementReferenceExamenSpec;
import fr.unedic.cali.dom.FormulaireSpec;
import fr.unedic.cali.dom.Individu;
import fr.unedic.cali.dom.IndividuSpec;
import fr.unedic.cali.dom.OdSpec;
import fr.unedic.cali.dom.RepriseSpec;
import fr.unedic.cali.dom.affectation.DecorReglementaire;
import fr.unedic.cali.dom.affectation.GammeAsuDelegueSpec;
import fr.unedic.cali.dom.affectation.GammeDelegueAbstrait;
import fr.unedic.cali.dom.affectation.ProduitAsuSpec;
import fr.unedic.cali.dom.affectation.ProduitSpec;
import fr.unedic.cali.dom.conteneurs.DonneesEntreeConstructionChronologie;
import fr.unedic.cali.dom.conteneurs.DonneesEntreePRC;
import fr.unedic.cali.dom.conteneurs.DonneesEntreesRecuperationMontant;
import fr.unedic.cali.dom.echange.Decision;
import fr.unedic.cali.occasionnel.outilsfonctionnels.CriteresExecutionPopulation;
import fr.unedic.cali.occasionnel.outilsfonctionnels.ExecutionPopulationSpec;
import fr.unedic.cali.occasionnel.outilsfonctionnels.FabriqueTraitementPopulationSpec;
import fr.unedic.cali.outilsfonctionnels.CREMHorsGamme;
import fr.unedic.cali.outilsfonctionnels.IOutilFonctionnelTraitementsErreurs;
import fr.unedic.cali.outilsfonctionnels.OutilFluxSillage;
import fr.unedic.cali.parcours.DomLiquidationDemande;
import fr.unedic.cali.parcours.ParcoursCali;
import fr.unedic.cali.parcours.ParcoursLiquidation;
import fr.unedic.cali.parcours.ResultatMigrationCalculProduit;
import fr.unedic.cali.utilitaire.decideur.logiques.DecideurDecisionVeto;
import fr.unedic.cali.utilitaire.decideur.metier.DecideurDecisionMotifRejet;
import fr.unedic.cali.utilitaire.decideur.spec.DecideurDecisionSpec;
import fr.unedic.cali.utilitaire.filtres.FiltreCaliSpec;
import fr.unedic.cali.utilitaire.filtres.composites.FiltreOuvertureDroitStandardAssurance;
import fr.unedic.cali.utilitaire.filtres.generiques.FiltreDecisionPourLigne;
import fr.unedic.cali.utilitaire.filtres.logiques.FiltreET;
import fr.unedic.cali.utilitaire.filtres.logiques.FiltreNegation;
import fr.unedic.cali.utilitaire.outils.OutilRecherche;
import fr.unedic.util.services.Contexte;
import fr.unedic.util.services.ContexteService;
import fr.unedic.util.services.CoucheLogiqueException;
import fr.unedic.util.services.Parcours;
import fr.unedic.util.services.Resultat;
import fr.unedic.util.temps.Chronologie;
import fr.unedic.util.temps.ChronologiePeriodes;
import fr.unedic.util.temps.ChronologieStandard;
import fr.unedic.util.temps.Damj;
import fr.unedic.util.temps.Periode;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

public class GammeAsuDelegue
  extends GammeDelegueAbstrait
  implements GammeAsuDelegueSpec
{
  private static final String DATE = "Date";
  private static final String ALLOC_MINI = "allocationMinimale";
  private static final String PARTIE_FIXE = "partieFixe";
  private static final String PLAFOND = "plafond";
  private static final String REVALO_SJR = "revalorisationSjr";
  private static final String SEUIL_MINI_AREF = "seuilMiniAref";
  private static final String COTISATION_RETR_COMPL = "cotisationRetraiteCompl";
  private static final String ALLOC_MINI_MAY = "allocationMinimaleMayotte";
  private static final String PLAFOND_MAY = "plafondMayotte";
  private static final String REVALO_SJR_MAY = "revalorisationSjrMayotte";
  private static final String SEUIL_MINI_AREMF = "seuilMiniAremf";
  private static final String VALEURS = "valeurs";
  private FabriqueExecutionPopulation fabriqueExecutionPopulation;
  private FabriqueTraitementPopulation fabriqueTraitementPopulation;
  private static final int CODE_EVT_DECLENCHEUR_EXAMEN = 1;
  
  public ParcoursLiquidation getParcoursLiquidation(fr.unedic.cali.dom.DemandeSpec demande)
  {
    return FabriqueParcoursLiquidationDemandeAsu.getParcoursLiquidation(demande);
  }
  
  public DomLiquidationDemande creerDomLiquidationDemande()
  {
    return new DomLiquidationAssurance();
  }
  
  public ParcoursCali getParcoursCreationDemande()
  {
    return new CreerDemandePrestation();
  }
  
  public Parcours getParcoursCreationFormulaire()
  {
    return new FabriquerFormulairesCali();
  }
  
  public void enregistrerBasePivot(fr.unedic.cali.dom.DemandeSpec demande)
    throws ApplicativeException
  {
    AlimentationBasePivot.enregistrerBasePivotGamme(demande);
  }
  
  public void alimenterBaseEchanges(fr.unedic.cali.dom.DemandeSpec demande, Decision decision)
    throws ApplicativeException
  {
    AlimenterBaseEchanges.alimenterDonneesGamme(demande, decision);
  }
  
  public Hashtable recupererDonneesImposees(fr.unedic.cali.dom.DemandeSpec demande)
    throws CoucheLogiqueException
  {
    return CREM.recupererDonneesImposees(demande);
  }
  
  public Hashtable getElementsDonneesImposeesVides()
    throws CoucheLogiqueException
  {
    return CREM.getElementsDonneesImposeesVides();
  }
  
  public Hashtable getElementsConstituantVides()
    throws CoucheLogiqueException
  {
    return CREM.getElementsConstitutantVides();
  }
  
  public Hashtable recupererElementsDecision(fr.unedic.cali.dom.DemandeSpec demande)
    throws CoucheLogiqueException
  {
    return CREMHorsGamme.recupererElementsDecision(demande);
  }
  
  public Hashtable getElementsDecisionVides()
    throws CoucheLogiqueException
  {
    return CREMHorsGamme.getElementsDecisionVides();
  }
  
  public FormulaireSpec creerFormulaire(fr.unedic.cali.autresdoms.cohab.sigma.demande.dom.spec.DemandeSpec demande)
  {
    FormulaireAsu formulaireAsu = new FormulaireAsuTemporaire();
    formulaireAsu.setDateDepot(demande.getDateDepot());
    formulaireAsu.setMotifEnvoi(demande.getTypeExamen());
    formulaireAsu.setIdPec(demande.getIdentifiantPec());
    formulaireAsu.setReferenceExterne(demande.getIdentifiantDemande());
    formulaireAsu.setPresenceAe(demande.getPresenceAE());
    formulaireAsu.setDemandeLiquidable(demande.getEtatLiquidable());
    formulaireAsu.setRefusFNE(demande.getRefusFNE());
    formulaireAsu.setDroitAuCongeReclassement(demande.isDroitCongeReclassement());
    formulaireAsu.setPareCrpCtpPropose(demande.getPropositionCrpCtp());
    formulaireAsu.setReferenceExterneDemandeLiee(demande.getReferenceRejetDV());
    formulaireAsu.setDeploiementInstruction(demande.getDeploiementDalInstruction());
    super.creerFormulaire(demande, formulaireAsu);
    return formulaireAsu;
  }
  
  public void stockerIdDecorSurDemande(fr.unedic.cali.dom.DemandeSpec demande, String idDecor)
  {
    ((DemandeAssuranceSpec)demande).setIdDecorDepuisPN(idDecor);
  }
  
  public boolean contientAlerteNonBloquanteProvoquantRemiseEnCause(fr.unedic.cali.dom.DemandeSpec demande)
  {
    boolean alerteA5MNB1 = demande.getAlertesNonBloquantes().containsKey("A5MNB1");
    boolean alerteA6MNB1 = false;
    return (alerteA5MNB1) || (alerteA6MNB1);
  }
  
  public void alimenterDomResultatMigrationCalcul(ResultatMigrationCalculProduit resultatMigration, DonneesAuDJIMigration donneeAuDJI)
  {
    RecuperationResultatMigrationCalcul.alimenterDomResultatMigrationCalcul(resultatMigration, donneeAuDJI);
  }
  
  public boolean estDecisionRenoncement(fr.unedic.cali.dom.DemandeSpec demande)
  {
    return (((Demande)demande).getAttribution() != null) && (((Demande)demande).getAttribution().estTopeeRenoncement());
  }
  
  public void setTopRenoncementDecision(fr.unedic.cali.dom.DemandeSpec demande, boolean top)
  {
    if (((Demande)demande).getAttribution() != null) {
      ((Demande)demande).getAttribution().setTopRenoncement(top);
    }
  }
  
  public void verifierPossibiliteAnnulerReexamen(fr.unedic.cali.dom.DemandeSpec demande)
    throws CoucheLogiqueException
  {
    ControleAnnulerReexamen.verifierAnnulerReexamen(demande);
  }
  
  public boolean estImputeeSurArce(fr.unedic.cali.dom.DemandeSpec demande)
  {
    Demande demandeAsu = (Demande)demande;
    boolean result = false;
    if ((demandeAsu.getDonneesTemporaires().getMontantAide() != null) && (demandeAsu.getDonneesTemporaires().getMontantAide().intValue() != 0)) {
      result = true;
    }
    return result;
  }
  
  private void ajouterChrono(ChronologieStandard asuC, ChronologieStandard chrono)
  {
    chrono.iterer();
    while (chrono.encoreSuivant())
    {
      EvenementParametre evtPf = (EvenementParametre)chrono.elementSuivant();
      ajouterEvenement(asuC, evtPf);
    }
  }
  
  private void ajouterEvenement(ChronologieStandard asuC, EvenementParametre evtParam)
  {
    Damj damjParam = evtParam.getDateEffet();
    boolean trouve = false;
    asuC.iterer();
    while ((asuC.encoreSuivant()) && (!trouve))
    {
      EvenementParametre evtAsu = (EvenementParametre)asuC.elementSuivant();
      Damj damjAsu = evtAsu.getDateEffet();
      if (damjParam.equals(damjAsu))
      {
        evtAsu.repercuter(evtParam);
        trouve = true;
      }
    }
    if (!trouve) {
      asuC.ajouter(evtParam);
    }
  }
  
  private ArrayList retourneArrayList(ChronologieStandard asuC)
  {
    ArrayList resultat = new ArrayList();
    
    asuC.iterer();
    while (asuC.encoreSuivant())
    {
      EvenementParametre evtAsu = (EvenementParametre)asuC.elementSuivant();
      Damj damjAsu = evtAsu.getDateEffet();
      
      Hashtable params = new Hashtable();
      
      params.put("Date", damjAsu);
      BigDecimal am = evtAsu.getAllocationMinimale(false);
      BigDecimal pf = evtAsu.getPartieFixe(false);
      BigDecimal p = evtAsu.getPlafond(false);
      BigDecimal rSjr = evtAsu.getRevalorisationSjr(false);
      BigDecimal smAref = evtAsu.getSeuilMinimalAREF();
      BigDecimal crC = evtAsu.getCotisationRetraiteComplementaire(false);
      
      BigDecimal amm = evtAsu.getAllocationMinimaleMayotte(false);
      BigDecimal pm = evtAsu.getPlafondMayotte(false);
      BigDecimal rSjrm = evtAsu.getRevalorisationSjrMayotte(false);
      BigDecimal smAremf = evtAsu.getSeuilMinimalAREMF(false);
      if (am != null) {
        params.put("allocationMinimale", am);
      }
      if (pf != null) {
        params.put("partieFixe", pf);
      }
      if (p != null) {
        params.put("plafond", p);
      }
      if (rSjr != null) {
        params.put("revalorisationSjr", rSjr);
      }
      if (smAref != null) {
        params.put("seuilMiniAref", smAref);
      }
      if (crC != null) {
        params.put("cotisationRetraiteCompl", crC);
      }
      if (smAremf != null) {
        params.put("seuilMiniAremf", smAremf);
      }
      if (rSjrm != null) {
        params.put("revalorisationSjrMayotte", rSjrm);
      }
      if (pm != null) {
        params.put("plafondMayotte", pm);
      }
      if (amm != null) {
        params.put("allocationMinimaleMayotte", amm);
      }
      resultat.add(params);
    }
    return resultat;
  }
  
  public ArrayList getParametres()
  {
    AccesAllocationMinimale allocMiniP = new AccesAllocationMinimale();
    AccesPartieFixe partieFixeP = new AccesPartieFixe();
    AccesPlafond plafondP = new AccesPlafond();
    AccesRevalorisationSjr revaloSjrP = new AccesRevalorisationSjr();
    AccesSeuilMinimalAREF seuilMiniArefP = new AccesSeuilMinimalAREF();
    AccesCotisationRetraiteComplementaire retrComplP = new AccesCotisationRetraiteComplementaire();
    
    AccesAllocationMinimaleMayotte allocMiniMayotteP = new AccesAllocationMinimaleMayotte();
    AccesPlafondMayotte plafondMayotteP = new AccesPlafondMayotte();
    AccesSeuilMinimalAREFM seuilMiniArefMayotteP = new AccesSeuilMinimalAREFM();
    AccesRevalorisationSjrMayotte revaloSjrMayotteP = new AccesRevalorisationSjrMayotte();
    
    ChronologieStandard allocMiniC = allocMiniP.getChronoValeursParametre();
    ChronologieStandard partieFixeC = partieFixeP.getChronoValeursParametre();
    ChronologieStandard plafondC = plafondP.getChronoValeursParametre();
    ChronologieStandard revaloSjrC = revaloSjrP.getChronoValeursParametre();
    ChronologieStandard seuilMiniArefC = seuilMiniArefP.getChronoValeursParametre();
    ChronologieStandard retrComplC = retrComplP.getChronoValeursParametre();
    
    ChronologieStandard allocMiniMayotteC = allocMiniMayotteP.getChronoValeursParametre();
    ChronologieStandard plafondMayotteC = plafondMayotteP.getChronoValeursParametre();
    ChronologieStandard seuilMiniArefMayotteC = seuilMiniArefMayotteP.getChronoValeursParametre();
    ChronologieStandard revaloSjrMayotteC = revaloSjrMayotteP.getChronoValeursParametre();
    
    ChronologieStandard asuC = (ChronologieStandard)allocMiniC.copier();
    
    ajouterChrono(asuC, partieFixeC);
    ajouterChrono(asuC, plafondC);
    ajouterChrono(asuC, revaloSjrC);
    ajouterChrono(asuC, seuilMiniArefC);
    ajouterChrono(asuC, retrComplC);
    
    ajouterChrono(asuC, allocMiniMayotteC);
    ajouterChrono(asuC, plafondMayotteC);
    ajouterChrono(asuC, seuilMiniArefMayotteC);
    ajouterChrono(asuC, revaloSjrMayotteC);
    
    return retourneArrayList(asuC);
  }
  
  private ArrayList retourneArrayListCatA2B(ChronologieStandard asuC)
  {
    ArrayList resultat = new ArrayList();
    
    asuC.iterer();
    while (asuC.encoreSuivant())
    {
      EvenementCategorieA2B evtAsu = (EvenementCategorieA2B)asuC.elementSuivant();
      Damj damjAsu = evtAsu.getDateEffet();
      
      Hashtable params = new Hashtable();
      
      params.put("Date", damjAsu);
      ArrayList categories = evtAsu.getValeurs();
      if (categories != null) {
        params.put("valeurs", categories);
      }
      resultat.add(params);
    }
    return resultat;
  }
  
  public ArrayList getCatA2BParam()
  {
    AccesSalaireForfaitaireJournalierCategorieA2B salCatA2B = AccesSalaireForfaitaireJournalierCategorieA2B.getInstance();
    ChronologieStandard catA2B = salCatA2B.getChronoValeursParametre();
    return retourneArrayListCatA2B(catA2B);
  }
  
  public boolean estReexecutable(CriteresExecutionPopulation criteres)
  {
    ExecutionPopulationSpec outil = getFabriqueExecutionPopulation().getInstance(criteres.getNomPopulation());
    if (outil != null) {
      return outil.estExecutable(criteres);
    }
    return false;
  }
  
  private FabriqueExecutionPopulation getFabriqueExecutionPopulation()
  {
    if (fabriqueExecutionPopulation == null) {
      fabriqueExecutionPopulation = new FabriqueExecutionPopulation();
    }
    return fabriqueExecutionPopulation;
  }
  
  public void positionnerCriteresQualifSurPas(fr.unedic.cali.dom.DemandeSpec demande, IndividuSpec individu, TravailSpec dernierSinistre)
    throws CoucheLogiqueException
  {
    ConteneurAccesDecorReglementaire conteneur = new ConteneurAccesDecorReglementaire();
    Damj dateFinDernierSinistre = dernierSinistre.getDateFin();
    
    conteneur.setDemande(demande);
    conteneur.setDateRecherche(dateFinDernierSinistre);
    conteneur.setDernierSinistre(dernierSinistre);
    
    DecorReglementaire decorReglementaire = AccesDecorReglementaire.getInstance().getDecor(conteneur);
    
    boolean coordCee = false;
    if ((demande instanceof Demande)) {
      coordCee = ((Demande)demande).getDonneesTemporaires().isEstCoordCee();
    }
    CriteresQualification critereQualification = new CriteresQualification(decorReglementaire, dernierSinistre, coordCee);
    
    AccesDecorReglementaire.getInstance().positionnerCriteresQualifSurPas(critereQualification, (Individu)individu);
  }
  
  public void controlerInvestigationFrauduleuse(DomLiquidationDemande dom)
  {
    DemandeAssuranceSpec demande = (DemandeAssuranceSpec)dom.getDemandeSpec();
    ContexteService contexteService = dom.getContexteService();
    if ((demande.getDossierExamen() instanceof OdAssuranceSpec))
    {
      fr.unedic.cali.asu.dom.AttributionAssuranceSpec attribution = (fr.unedic.cali.asu.dom.AttributionAssuranceSpec)demande.getDossierExamen();
      if (attribution.isInvestigationFraude()) {
        OutilFluxSillage.declarerDemandeIF(contexteService, attribution.getDateAttribution(), demande.getFormulaire().getReferenceExterne());
      }
    }
  }
  
  public void recalculerSurAnnulerReexamen(fr.unedic.cali.dom.DemandeSpec demande)
    throws CoucheLogiqueException
  {
    ((ProduitAsuSpec)demande.getDossierAffectation().getProduit()).recalculerSurAnnulerReexamen(demande);
  }
  
  public Resultat executerExamenFilEau(IndividuSpec individu, ComportementExamenFilEauSpec comportement, Damj dateEvenement)
    throws ApplicativeException
  {
    ContexteService contexteService = individu.getContexteService();
    DomExamenAuFilEau domExamenFilEau = new DomExamenAuFilEau(individu, contexteService);
    
    domExamenFilEau.setDateEvenementDeclencheur(comportement.getDateEvenementDeclencheur());
    
    domExamenFilEau.setNatureEvenementDeclencheur(1);
    if (comportement.getIdentifiantComportement().equals(ComportementExamenFilEauSpec.ID_COMPORTEMENT_EFE_AUTO)) {
      domExamenFilEau.setTypeDeclenchementExamen(0);
    } else {
      domExamenFilEau.setTypeDeclenchementExamen(1);
    }
    domExamenFilEau.setDateEvenement(dateEvenement);
    
    domExamenFilEau.setModeSimulationActif(comportement.isModeSimulationActif());
    
    domExamenFilEau.setCalculAffiliationSimplifieeActif(comportement.isCalculAffiliationSimplifieeActif());
    
    domExamenFilEau.setNombreMaximumFctATraiter(comportement.getNombreMaximumFctATraiter());
    
    Contexte contexteParcours = new Contexte();
    contexteParcours.setDonnees(domExamenFilEau);
    
    Parcours parcours = new ParcoursExamenFilEau();
    return parcours.effectuerParcours(contexteParcours);
  }
  
  public Resultat executerSimulationAffiliation(DomSimulationAffiliation domSimulationAffiliation)
    throws ApplicativeException
  {
    return OutilSimulationAffiliation.calculAffi(domSimulationAffiliation);
  }
  
  protected FabriqueTraitementPopulationSpec getFabriqueTraitementPopulation()
  {
    if (fabriqueTraitementPopulation == null) {
      fabriqueTraitementPopulation = new FabriqueTraitementPopulation();
    }
    return fabriqueTraitementPopulation;
  }
  
  public void mettreEnReexamen(fr.unedic.cali.dom.DemandeSpec demande)
    throws CoucheLogiqueException
  {
    if (!((DemandeAssuranceSpec)demande).getModeSimulation()) {
      ((DemandeAssuranceSpec)demande).setDroitOptionReadmission(false);
    }
  }
  
  public Damj getDateFaitGenerateurOdPrecedente(fr.unedic.cali.dom.DemandeSpec demande)
  {
    if (demande != null) {
      return ((DemandeAssuranceSpec)demande).getDateFaitGenerateurOdPrecedente();
    }
    return null;
  }
  
  public Damj getDateFaitGenerateurOdPrecedenteSaufAfd(fr.unedic.cali.dom.DemandeSpec demande)
  {
    Damj dateFgdOdPrecedente = null;
    if (demande != null)
    {
      FiltreET filtre = new FiltreET();
      filtre.ajouterFiltre(new FiltreNegation(new FiltreDecisionPourLigne("ASU_FDS12")));
      filtre.ajouterFiltre(new FiltreOuvertureDroitStandardAssurance(true, true, true, false, demande));
      
      OdSpec odPrecedente = (OdSpec)OutilRecherche.rechercherDecisionPrecedente(demande.getDemandeur().getChronoDemandesNonTriees(), demande, filtre);
      if (odPrecedente != null) {
        dateFgdOdPrecedente = ((fr.unedic.cali.asu.dom.AttributionAssuranceSpec)odPrecedente).getFaitGenerateur().getDateFaitGenerateur();
      }
    }
    return dateFgdOdPrecedente;
  }
  
  public Damj getDateFaitGenerateurOdPrecedenteSaufAfdEtAps(fr.unedic.cali.dom.DemandeSpec demande)
  {
    Damj dateFgdOdPrecedente = null;
    if (demande != null)
    {
      FiltreET filtre = new FiltreET();
      filtre.ajouterFiltre(new FiltreNegation(new FiltreDecisionPourLigne("ASU_FDS12")));
      filtre.ajouterFiltre(new FiltreNegation(new FiltreDecisionPourLigne("ASU_SSP07")));
      
      filtre.ajouterFiltre(new FiltreOuvertureDroitStandardAssurance(true, true, true, false, demande));
      OdSpec odPrecedente = (OdSpec)OutilRecherche.rechercherDecisionPrecedente(demande.getDemandeur().getChronoDemandesNonTriees(), demande, filtre);
      if (odPrecedente != null) {
        dateFgdOdPrecedente = ((fr.unedic.cali.asu.dom.AttributionAssuranceSpec)odPrecedente).getFaitGenerateur().getDateFaitGenerateur();
      }
    }
    return dateFgdOdPrecedente;
  }
  
  public Damj getDateEffetMaintien(AttributionSpec attrib)
  {
    if ((attrib instanceof fr.unedic.cali.asu.dom.AttributionAssuranceSpec))
    {
      fr.unedic.cali.asu.dom.AttributionAssuranceSpec attribution = (fr.unedic.cali.asu.dom.AttributionAssuranceSpec)attrib;
      DemandeMaintien demandeMaintien = RechercherDemandeMaintien.rechercherDemandeMaintien(attribution.getDemande().getDemandeur(), attribution);
      if ((demandeMaintien != null) && ((demandeMaintien.getDossierExamen() instanceof Accord)) && (!demandeMaintien.estEnReExamen())) {
        return demandeMaintien.getDateEffet();
      }
    }
    return null;
  }
  
  public void initialiserDemandeAssociee(Individu individu, fr.unedic.cali.dom.DemandeSpec pDemande)
  {
    Demande demande = (Demande)pDemande;
    if (demande.getDonneesDemandeAssociee() != null)
    {
      Demande demandeFinancement = demande.getDonneesDemandeAssociee().getDemandeAssociee();
      if (demandeFinancement != null) {
        demandeFinancement.setDemandeur(individu);
      }
    }
  }
  
  public int definirStatutUt(AttributionSpec attribution, ChronologiePeriodes periodesDecalantes, int nbPPA, boolean contientFormation, UniteTraitement ut, ArretProduitAvecRaison arretProduitAvecRaison, FacadeCalculProduitSpec facadeCalculProduit)
    throws CoucheLogiqueException
  {
    return DefinitionStatutUtTraitementActiviteReduite.definirStatutUt(attribution, periodesDecalantes, nbPPA, contientFormation, ut, arretProduitAvecRaison, facadeCalculProduit);
  }
  
  public boolean estDemandeFinDroitAre(fr.unedic.cali.dom.DemandeSpec pDemande)
  {
    DemandeAssuranceSpec demande = (DemandeAssuranceSpec)pDemande;
    return demande.estUneDemandeAre();
  }
  
  public boolean estDemandeFinDroitAsrAtp(fr.unedic.cali.dom.DemandeSpec pDemande)
  {
    DemandeAssuranceSpec demande = (DemandeAssuranceSpec)pDemande;
    return (demande.estUneDemandeFinDroitAsr()) || (demande.estUneDemandeFinDroitAtp());
  }
  
  public boolean estUnDroitSecteurPublic(fr.unedic.cali.dom.DemandeSpec pDemande)
  {
    boolean estUnDroitSecteurPublic = (pDemande.getClassementAdministratif() != null) && (pDemande.getClassementAdministratif().getTypeClassement().equalsIgnoreCase("SP"));
    if (!estUnDroitSecteurPublic)
    {
      Demande demande = (Demande)pDemande;
      if (demande.getAttribution() != null)
      {
        fr.unedic.cali.asu.dom.AttributionAssuranceSpec attribution = demande.getAttribution();
        ProduitAsuSpec produit = (ProduitAsuSpec)attribution.getProduit();
        
        estUnDroitSecteurPublic = !produit.estCompetenceAdministrativeRac(attribution);
      }
    }
    return estUnDroitSecteurPublic;
  }
  
  public boolean estFinancementPartage(fr.unedic.cali.dom.DemandeSpec pDemande)
  {
    boolean estFinancementPartage = false;
    Demande demande = (Demande)pDemande;
    if ((demande.getDonneesDemandeAssociee() != null) && (demande.getDonneesDemandeAssociee().getDemandeAssociee() != null))
    {
      Demande demandeFinancement = demande.getDonneesDemandeAssociee().getDemandeAssociee();
      if ((demandeFinancement.getDossierExamen() instanceof FinancementSpec))
      {
        FinancementSpec financement = (FinancementSpec)demandeFinancement.getDossierExamen();
        estFinancementPartage = "P".equals(financement.getNatureFinancement());
      }
    }
    return estFinancementPartage;
  }
  
  public void enregistrerBasePivotAides(fr.unedic.cali.dom.DemandeSpec demande)
    throws ApplicativeException
  {}
  
  public Periode determinerPrc(DonneesEntreePRC donneesEntreePRC)
    throws ApplicativeException
  {
    return DelaiRecherche.getInstance().determinerPrc(donneesEntreePRC);
  }
  
  public Chronologie determinerChronoActiviteInappartenancePrc(DonneesEntreeConstructionChronologie donneesEntree)
    throws ApplicativeException
  {
    return ConstructionChronologie.determinerChronoActivitesPrcPourInappartenance(donneesEntree);
  }
  
  public Chronologie determinerChronoActiviteSalariePrc(DonneesEntreeConstructionChronologie donneesEntree)
    throws ApplicativeException
  {
    return ConstructionChronologie.determinerChronoActivitesPrc(donneesEntree);
  }
  
  public Chronologie determinerChronoPeriodeDeductiblePrc(DonneesEntreeConstructionChronologie donneesEntree)
    throws ApplicativeException
  {
    return ConstructionChronologie.determinerChronoPeriodesDeductiblesPrc(donneesEntree);
  }
  
  public Chronologie getChronologieCatA2BParam()
  {
    AccesSalaireForfaitaireJournalierCategorieA2B salCatA2B = AccesSalaireForfaitaireJournalierCategorieA2B.getInstance();
    return salCatA2B.getChronoValeursParametre();
  }
  
  public boolean notifierAttributionPourEESSI(fr.unedic.cali.dom.DemandeSpec pDemande)
  {
    boolean retour = false;
    if ((pDemande instanceof Demande))
    {
      Demande demande = (Demande)pDemande;
      fr.unedic.cali.asu.dom.AttributionAssuranceSpec attributionAssurance = demande.getAttribution();
      retour = (attributionAssurance != null) && (attributionAssurance.notifierEESSI());
    }
    return retour;
  }
  
  public DecideurDecisionSpec determinerDecideursPourComportement(String codeComportement)
  {
    if ("comportementBatchDefautRejetB70B41".equals(codeComportement))
    {
      DecideurDecisionVeto decideur = new DecideurDecisionVeto();
      
      DecideurDecisionMotifRejet decideurRejet44vers41 = new DecideurDecisionMotifRejet(44, 41);
      
      DecideurDecisionMotifRejet decideurRejet45vers41 = new DecideurDecisionMotifRejet(45, 41);
      
      decideur.ajouterDecideur(decideurRejet44vers41);
      decideur.ajouterDecideur(decideurRejet45vers41);
      
      return decideur;
    }
    if ("comportementBatchDefautRejetB47B4x".equals(codeComportement))
    {
      DecideurDecisionVeto decideur = new DecideurDecisionVeto();
      
      DecideurDecisionMotifRejet decideurRejet47vers41 = new DecideurDecisionMotifRejet(47, 41);
      
      DecideurDecisionMotifRejet decideurRejet47vers42 = new DecideurDecisionMotifRejet(47, 42);
      
      DecideurDecisionMotifRejet decideurRejet47vers43 = new DecideurDecisionMotifRejet(47, 43);
      
      DecideurDecisionMotifRejet decideurRejet47vers44 = new DecideurDecisionMotifRejet(47, 44);
      
      DecideurDecisionMotifRejet decideurRejet47vers45 = new DecideurDecisionMotifRejet(47, 45);
      
      DecideurDecisionMotifRejet decideurRejet47vers46 = new DecideurDecisionMotifRejet(47, 46);
      
      DecideurDecisionMotifRejet decideurRejet47vers49 = new DecideurDecisionMotifRejet(47, 49);
      
      DecideurDecisionMotifRejet decideurRejet41vers47 = new DecideurDecisionMotifRejet(41, 47);
      
      DecideurDecisionMotifRejet decideurRejet42vers47 = new DecideurDecisionMotifRejet(42, 47);
      
      DecideurDecisionMotifRejet decideurRejet43vers47 = new DecideurDecisionMotifRejet(43, 47);
      
      DecideurDecisionMotifRejet decideurRejet44vers47 = new DecideurDecisionMotifRejet(44, 47);
      
      DecideurDecisionMotifRejet decideurRejet45vers47 = new DecideurDecisionMotifRejet(45, 47);
      
      DecideurDecisionMotifRejet decideurRejet46vers47 = new DecideurDecisionMotifRejet(46, 47);
      
      DecideurDecisionMotifRejet decideurRejet49vers47 = new DecideurDecisionMotifRejet(49, 47);
      
      decideur.ajouterDecideur(decideurRejet47vers41);
      decideur.ajouterDecideur(decideurRejet47vers42);
      decideur.ajouterDecideur(decideurRejet47vers43);
      decideur.ajouterDecideur(decideurRejet47vers44);
      decideur.ajouterDecideur(decideurRejet47vers45);
      decideur.ajouterDecideur(decideurRejet47vers46);
      decideur.ajouterDecideur(decideurRejet47vers49);
      
      decideur.ajouterDecideur(decideurRejet41vers47);
      decideur.ajouterDecideur(decideurRejet42vers47);
      decideur.ajouterDecideur(decideurRejet43vers47);
      decideur.ajouterDecideur(decideurRejet44vers47);
      decideur.ajouterDecideur(decideurRejet45vers47);
      decideur.ajouterDecideur(decideurRejet46vers47);
      decideur.ajouterDecideur(decideurRejet49vers47);
      
      return decideur;
    }
    if ("comportementBatchReconductionRejet".equals(codeComportement))
    {
      DecideurDecisionVeto decideur = new DecideurDecisionVeto();
      
      DecideurDecisionMotifRejet decideurRejetReconduit = new DecideurDecisionMotifRejet(-1, -1);
      
      decideur.ajouterDecideur(decideurRejetReconduit);
      
      return decideur;
    }
    return null;
  }
  
  public FiltreCaliSpec retournerFiltreAttributionGammeAsuProduit()
  {
    return new FiltreAttributionGammeAsuProduit();
  }
  
  public Class getClassGestionnaireErreur()
  {
    return GestionnaireErreur.getClassInstance();
  }
  
  public void traiterMiseEnReexamen(fr.unedic.cali.dom.DemandeSpec demande, List listeElementsComparaison) {}
  
  public DonneesEntreesRecuperationMontant mapperDonneesEntreesRecuperationMontant(AttributionSpec attribution)
  {
    OutilConstructionDonneesEntreesRecuperationMontant outil = new OutilConstructionDonneesEntreesRecuperationMontant();
    return outil.creerDonneesEntreesRecuperationMontant(attribution);
  }
  
  public BigDecimal recupereParametresAllocationMinimaleAre(Damj dateAccesParametre)
  {
    EvenementParametre evenement = ParametresIndemnisation.getParametresIndemnisation().getElementActif(dateAccesParametre);
    return evenement.getAllocationMinimale();
  }
  
  public void controlerPresenceDemandeRevision(fr.unedic.cali.dom.DemandeSpec demandePrestationsCourante, fr.unedic.cali.dom.AttributionAssuranceSpec attributionAssurancePrecedente)
    throws CoucheLogiqueException
  {
    OutilVerificationPresenceRevision outilRevision = new OutilVerificationPresenceRevision();
    if ((outilRevision.recupererPansAttributionArcePrecedente(demandePrestationsCourante, attributionAssurancePrecedente) == null) && (attributionAssurancePrecedente.getCompetenceAdministrative() == 1)) {
      outilRevision.controlerPresenceDemandeRevision(demandePrestationsCourante, attributionAssurancePrecedente);
    }
  }
  
  public void controlerPresenceDemandeRevisionPostLiquidation(fr.unedic.cali.dom.DemandeSpec demandePrestationsCourante, fr.unedic.cali.dom.AttributionAssuranceSpec attributionAssurancePrecedente)
    throws CoucheLogiqueException
  {
    OutilVerificationPresenceRevision outilRevision = new OutilVerificationPresenceRevision();
    
    Periode pansArce = outilRevision.recupererPansAttributionArcePrecedente(demandePrestationsCourante, attributionAssurancePrecedente);
    if ((pansArce != null) && (attributionAssurancePrecedente.getCompetenceAdministrative() == 1))
    {
      Demande demande = (Demande)demandePrestationsCourante;
      if ((demande.getAttribution() instanceof RepriseSpec))
      {
        outilRevision.controlerPresenceDemandeRevision(demandePrestationsCourante, attributionAssurancePrecedente);
      }
      else if ((demande.getAttribution() instanceof OdSpec))
      {
        outilRevision = new OutilVerificationPresenceRevisionOD();
        ((OutilVerificationPresenceRevisionOD)outilRevision).setPansArce(pansArce);
        outilRevision.controlerPresenceDemandeRevision(demandePrestationsCourante, attributionAssurancePrecedente);
      }
    }
  }
  
  public Damj calculerPointDepartCSP(fr.unedic.cali.dom.DemandeSpec demande)
  {
    Damj dateDebutCSP = null;
    if ((demande instanceof Demande)) {
      dateDebutCSP = OutilAsp.getInstance().calculerPointDepartCSP((Demande)demande);
    }
    return dateDebutCSP;
  }
  
  public boolean detecterAssSuiteDecheance(fr.unedic.cali.dom.DemandeSpec demande)
  {
    boolean sontDossiersExamensPresents = OutilDemandeASS.verifierPresenceDossierExamenAdmissionEtReprise((Demande)demande);
    
    List<Integer> listeCodeMotifEchecAdmission = null;
    List<Integer> listeCodeMotifEchecReprise = null;
    int codeProduit = 0;
    String typeEre = null;
    if (sontDossiersExamensPresents)
    {
      DossierExamenAssuranceSpec dossierExamenAdmission = (DossierExamenAssuranceSpec)((Demande)demande).getDossierAffectationAdmission().getDossierExamen();
      
      DossierExamenAssuranceSpec dossierExamenReprise = (DossierExamenAssuranceSpec)((Demande)demande).getDossierAffectationReprise().getDossierExamen();
      
      listeCodeMotifEchecReprise = dossierExamenReprise.getListConditionAttributionObjectifReprise().getListeCodeMotifEchec();
      listeCodeMotifEchecAdmission = dossierExamenAdmission.getListConditionAttributionObjectifAdmission().getListeCodeMotifEchec();
      codeProduit = demande.getDossierAffectation().getProduit().getCode();
      typeEre = demande.getEvenementReferenceExamen().getTypeExamen();
    }
    boolean retour = OutilDemandeASS.estDetecteConditionDemandeASSSuiteDecheance(listeCodeMotifEchecReprise, listeCodeMotifEchecAdmission, codeProduit, typeEre);
    return retour;
  }
  
  public boolean detecterRepriseAssSuiteReinscription(fr.unedic.cali.dom.DemandeSpec demande)
  {
    DossierAffectation dossierAffectation = (DossierAffectation)((Demande)demande).getDossierAffectation();
    List<Integer> listeCodeMotifEchecAdmission = null;
    if ((dossierAffectation != null) && (dossierAffectation.getDossierExamen() != null))
    {
      DossierExamenAssuranceSpec dossierExamenAdmission = (DossierExamenAssuranceSpec)dossierAffectation.getDossierExamen();
      
      listeCodeMotifEchecAdmission = dossierExamenAdmission.getConditionsAttributionActives().getListeCodeMotifEchec();
    }
    return OutilDemandeASS.estDetecteConditionRepriseAssSuiteReinscription(listeCodeMotifEchecAdmission);
  }
  
  public IOutilFonctionnelTraitementsErreurs getOutilFonctionnelTraitementErreurLiquidationAutomatique()
  {
    return OutilFonctionnelTraitementsErreurs.getInstance();
  }
  
  public EvenementReferenceExamenSpec recupererEvenementReferenceExamen(String typeExamen)
  {
    return ConstitutionEvenementReferenceExamen.recupererEvenementReferenceExamen(typeExamen);
  }
  
  public boolean controlerPrescription(FormulaireSpec formulaire)
  {
    return ControlePrescription.controlerPrescription(formulaire);
  }
  
  public void traitementPostValidation(fr.unedic.cali.dom.DemandeSpec demande)
    throws ApplicativeException
  {}
  
  public void setDateDepotOrigine(fr.unedic.cali.dom.DemandeSpec demande, Damj dateDepote)
  {
    ((Demande)demande).getFormulaireAsu().setDateDepotOrigine(dateDepote);
  }
}

/* Location:
 * Qualified Name:     GammeAsuDelegue
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */