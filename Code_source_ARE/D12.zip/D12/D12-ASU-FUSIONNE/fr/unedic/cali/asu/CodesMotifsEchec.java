package fr.unedic.cali.asu;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class CodesMotifsEchec
{
  public static final int ECHEC_INCONNU = 0;
  public static final int ECHEC_CONTEXTE_INSUFFISANT = 1;
  public static final int CAP_SANS_OBJET = 0;
  public static final String LIB_CAP_SANS_OBJET = "";
  public static final int ECHEC_CAP01_ABSENCE_IDE_OU_CHOMAGE_ATTESTE = 11;
  public static final String LIB_ECHEC_CAP01_ABSENCE_IDE_OU_CHOMAGE_ATTESTE = "Absence d'IDE ou chomage attesté";
  public static final int ECHEC_CAP01_CHGT_CATEGORIE = 12;
  public static final String LIB_ECHEC_CAP01_CHGT_CATEGORIE = "Demande non valide suite changement de catégorie";
  public static final int ECHEC_CAP01_PEC_ANNULEE = 13;
  public static final String LIB_ECHEC_CAP01_PEC_ANNULEE = "Demande sur Pec annulée";
  public static final int ECHEC_CAP01_INSCRIPTIO_KO = 14;
  public static final String LIB_CAP01_INSCRIPTIO_KO = "Le demandeur n'est pas inscrit selon les bonnes modalités";
  public static final int ECHEC_CAP02_APTITUDE_PHYSIQUE_NON_REMPLIE = 21;
  public static final String LIB_ECHEC_CAP02_APTITUDE_PHYSIQUE_NON_REMPLIE = "Aptitude physique non remplie";
  public static final int ECHEC_CAP04_ABSENCE_FAIT_GENERATEUR = 41;
  public static final String LIB_ECHEC_CAP04_ABSENCE_FAIT_GENERATEUR = "Absence de fait générateur de droit";
  public static final int ECHEC_CAP04_ACTIVITE_HORS_CHAMPS = 42;
  public static final String LIB_ECHEC_CAP04_ACTIVITE_HORS_CHAMPS = "Activité hors champ";
  public static final int ECHEC_CAP04_CONTRAT_TRAVAIL_NON_ROMPU = 43;
  public static final String LIB_ECHEC_CAP04_CONTRAT_TRAVAIL_NON_ROMPU = "Contrat de travail non rompu";
  public static final int ECHEC_CAP04_ABSENCE_FCT_DANS_DELAI_FORCLUSION = 44;
  public static final String LIB_ECHEC_CAP04_ABSENCE_FCT_DANS_DELAI_FORCLUSION = "Absence de FCT dans le délai de forclusion";
  public static final int ECHEC_CAP04_ABSENCE_FCT_DANS_DELAI_FORCLUSION_ALLONGE = 45;
  public static final String LIB_ECHEC_CAP04_ABSENCE_FCT_DANS_DELAI_FORCLUSION_ALLONGE = "Absence de FCT dans le delai de forclusion allongé";
  public static final int ECHEC_CAP04_FAIT_GENERATEUR_NON_ATTESTE = 46;
  public static final String LIB_ECHEC_CAP04_FAIT_GENERATEUR_NON_ATTESTE = "Fait générateur de droit non attesté";
  public static final int ECHEC_CAP04_ABSENCE_ACTIVITE_EN_FRANCE = 47;
  public static final String LIB_ECHEC_CAP04_ABSENCE_ACTIVITE_EN_FRANCE = "Absence d'activité en France";
  public static final int ECHEC_CAP04_FCT_HORS_DES_DEUX_MOIS_AVANT_FDD_ARE = 49;
  public static final String LIB_ECHEC_CAP04_FCT_HORS_DES_DEUX_MOIS_AVANT_FDD_ARE = "La FCT n'est pas incluse dans les deux mois précédents la fin de droit ARE";
  public static final int ECHEC_CAP05_PRESENCE_ACTIVITE_CONSERVEE = 51;
  public static final String LIB_ECHEC_CAP05_PRESENCE_ACTIVITE_CONSERVEE = "Présence d'une activité conservée";
  public static final int ECHEC_CAP06_PLUS_DE_XX_ANS = 61;
  public static final String LIB_ECHEC_CAP06_PLUS_DE_XX_ANS = "Le DE a plus de %0";
  public static final int ECHEC_CAP06_MOINS_DE_XX_ANS_ET_PLUS_DE_XX_TRIMESTRES = 62;
  public static final String LIB_ECHEC_CAP06_MOINS_DE_XX_ANS_ET_PLUS_DE_XX_TRIMESTRES = "le DE a plus de %0 et plus de %1 trimestres";
  public static final int ECHEC_CAP06_RETRAITE_ANTICIPEE = 625;
  public static final String LIB_ECHEC_CAP06_RETRAITE_ANTICIPEE = "Le demandeur est titulaire d'une retraite anticipée";
  public static final int ECHEC_CAP06_RETRAITE_LIQUIDEE = 63;
  public static final String LIB_ECHEC_CAP06_RETRAITE_LIQUIDEE = "Condition âge non remplie et retraite liquidée";
  public static final int ECHEC_CAP06_TITULAIRE_PENSION_CAN = 64;
  public static final String LIB_ECHEC_CAP06_TITULAIRE_PENSION_CAN_ET_RACCORDEMENT = "Titulaire pension CAN et raccordement";
  public static final String LIB_ECHEC_CAP06_GENERIQUE = "Condition age non remplie";
  public static final int ECHEC_CAP07_DUREE_AFFILIATION_INSUFFISANTE = 71;
  public static final String LIB_ECHEC_CAP07_DUREE_AFFILIATION_INSUFFISANTE = "Durée affiliation insuffisante";
  public static final int ECHEC_CAP09_DV_MOTIF_NON_LEGITIME = 91;
  public static final String LIB_ECHEC_CAP09_DV_MOTIF_NON_LEGITIME = "Départ volontaire motif non légitime";
  public static final int ECHEC_CAP09_DV_MOTIF_NON_LEGITIME_ET_ACTIVITE_INSUFFISANTE = 92;
  public static final String LIB_ECHEC_CAP09_DV_MOTIF_NON_LEGITIME_ET_ACTIVITE_INSUFFISANTE = "Départ volontaire motif non légitime suivi d'une activité insuffisante";
  public static final int ECHEC_CAP09_EXAMEN_121_JOURS_APRES_DV_MOTIF_NON_LEGITIME = 93;
  public static final String LIB_ECHEC_CAP09_EXAMEN_121_JOURS_APRES_DV_MOTIF_NON_LEGITIME = "Examen au 121e jour apres départ volontaire motif non légitime";
  public static final int ECHEC_CAP09_PERIODE_DISPONIBILITE_VOLONTAIRE = 94;
  public static final String LIB_ECHEC_CAP09_PERIODE_DISPONIBILITE_VOLONTAIRE = "Période de disponibilité/suspension volontaire";
  public static final int ECHEC_CAP12_ACTIVITE_CONSERVEE_SUPERIEURE_AUX_SEUILS = 121;
  public static final String LIB_ECHEC_CAP12_ACTIVITE_CONSERVEE_SUPERIEURE_AUX_SEUILS = "Activité conservée superieure aux seuils";
  public static final int ECHEC_CAP12_ACTIVITE_CONSERVEE_MEME_EMPLOYEUR = 122;
  public static final String LIB_ECHEC_CAP12_ACTIVITE_CONSERVEE_MEME_EMPLOYEUR = "Même employeur pour l'activité perdue et conservée";
  public static final int ECHEC_CAP12_PANS_OUVERTE_SUITE_ARCE = 123;
  public static final String LIB_ECHEC_CAP12_PANS_OUVERTE_SUITE_ARCE = "L'ANS ayant ouvert l'ARCE est toujours en cours";
  public static final int ECHEC_CAP14_NB_ADMISSION_TROP_GRAND_FILIERE_COURTE = 97;
  public static final String LIB_ECHEC_CAP14_NB_ADMISSION_TROP_GRAND_FILIERE_COURTE = "Nombre de droits AFD trop grand pour une filière courte";
  public static final int ECHEC_CAP14_NB_ADMISSION_TROP_GRAND_FILIERE_INTERMEDIAIRE = 98;
  public static final String LIB_ECHEC_CAP14_NB_ADMISSION_TROP_GRAND_FILIERE_INTERMEDIAIRE = "Nombre de droits AFD trop grand pour une filière intermédiaire";
  public static final int ECHEC_CAP14_NB_ADMISSION_TROP_GRAND_FILIERE_LONGUE = 99;
  public static final String LIB_ECHEC_CAP14_NB_ADMISSION_TROP_GRAND_FILIERE_LONGUE = "Nombre de droits AFD trop grand pour une filière longue";
  public static final int ECHEC_CAP14_ABSENCE_REJET_CLAUSE_RATTRAPAGE = 141;
  public static final String LIB_ECHEC_CAP14_ABSENCE_REJET_CLAUSE_RATTRAPAGE = "Absence de rejet clause de rattrapage";
  public static final int ECHEC_CAP17_LIBRE_CHOIX_TAUX_PLEIN = 171;
  public static final String LIB_ECHEC_CAP17_LIBRE_CHOIX_TAUX_PLEIN = "Complément de Libre Choix d'activité à taux plein a la date d'OD";
  public static final int ECHEC_CAP17_LIBRE_CHOIX_TAUX_PARTIEL = 172;
  public static final String LIB_ECHEC_CAP17_LIBRE_CHOIX_TAUX_PARTIEL = "Complément de Libre Choix d'activité à taux partiel a la date d'OD";
  public static final int ECHEC_CAP18_MONTANT_NUL = 181;
  public static final String LIB_ECHEC_CAP18_MONTANT_NUL = "Condition de cumul non remplie";
  public static final int ECHEC_CAP20_PRESENCE_DECISION_CP_CSR = 201;
  public static final String LIB_ECHEC_CAP20_PRESENCE_DECISION_CP_CSR = "Avis IPR défavorable";
  public static final int ECHEC_CAP21_CONDITION_28JOURS_SUSPENSION_CSR = 202;
  public static final String LIB_ECHEC_CAP21_CONDITION_28JOURS_SUSPENSION_CSR = "Condition des %0 jours de suspension non remplie";
  public static final String LIB_ECHEC_CAP21_GENERIQUE = "Condition des jours de suspension non remplie";
  public static final int ECHEC_CAP27_RELIQUAT_EPUISE = 271;
  public static final String LIB_ECHEC_CAP27_RELIQUAT_EPUISE = "Reliquat de droit épuisé depuis le %0";
  public static final int ECHEC_CAP27_RELIQUAT_DECHU = 272;
  public static final String LIB_ECHEC_CAP27_RELIQUAT_DECHU = "Reliquat de droit déchu depuis le %0";
  public static final int ECHEC_CAP27_RELIQUAT_ETEINT = 273;
  public static final String LIB_ECHEC_CAP27_RELIQUAT_ETEINT = "Reliquat de droit éteint depuis le %0";
  public static final String LIB_ECHEC_CAP27_EPUISE_GENERIQUE = "Reliquat de droit épuisé";
  public static final String LIB_ECHEC_CAP27_DECHU_GENERIQUE = "Reliquat de droit déchu";
  public static final String LIB_ECHEC_CAP27_ETEINT_GENERIQUE = "Reliquat de droit éteint";
  public static final int ECHEC_CAP26_CONDITION_ANCIENNETE = 261;
  public static final String LIB_ECHEC_CAP26_CONDITION_ANCIENNETE = "Condition ancienneté non remplie";
  public static final int ECHEC_PAS_ASSEZ_AFFILIATION = 300;
  public static final String LIB_ECHEC_PAS_ASSEZ_AFFILIATION = "Durée affiliation insuffisante";
  public static final int ECHEC_CAP_FIN_ASR = 801;
  private static final String LIB_ECHEC_CAP_FIN_ASR = "Absence de reliquat ARE suite à fin ASR";
  public static final int ECHEC_CAP_FIN_ATP = 802;
  private static final String LIB_ECHEC_CAP_FIN_ATP = "Absence de reliquat ARE suite à fin ATP";
  public static final int ECHEC_CAP_FIN_ASP = 803;
  private static final String LIB_ECHEC_CAP_FIN_ASP = "Absence de reliquat ARE suite à fin ASP";
  private static Map<BigDecimal, String> libelleEchecCap = new HashMap();
  public static final int ECHEC_RELIQUAT = 980;
  public static final int ECHEC_CAM01_AGE_MINIMUM = 981;
  public static final int ECHEC_CAM02_NOMBRE_TRIMESTRES = 982;
  public static final int ECHEC_CAM03_APPARTENANCE_MAINTIEN = 983;
  public static final int ECHEC_CAM03_ACTIVITE_MAINTIEN = 984;
  public static final int ECHEC_CAM04_NOMBRE_JOURS_INDEMNISATION = 985;
  public static final int ECHEC_CAM05_DECISION_CP = 986;
  public static final int ECHEC_CAM05_ABSCENCE_INFO = 987;
  public static final int CODE_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_1 = 421;
  public static final String LIB_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_1 = "Statut de conjoint salarié";
  public static final int CODE_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_2 = 422;
  public static final String LIB_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_2 = "Gérant majoritaire";
  public static final int CODE_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_3 = 423;
  public static final String LIB_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_3 = "Gérant égalitaire";
  public static final int CODE_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_4 = 424;
  public static final String LIB_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_4 = "Gérant de société";
  public static final int CODE_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_5 = 425;
  public static final String LIB_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_5 = "Associé égalitaire";
  public static final int CODE_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_6 = 426;
  public static final String LIB_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_6 = "Gérant associé de la société";
  public static final int CODE_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_7 = 427;
  public static final String LIB_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_7 = "Gérant commandité de la société";
  public static final int CODE_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_8 = 428;
  public static final String LIB_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_8 = "Président directeur général";
  public static final int CODE_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_9 = 429;
  public static final String LIB_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_9 = "Directeur général administrateur";
  public static final int CODE_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_10 = 4210;
  public static final String LIB_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_10 = "Directeur général non administrateur";
  public static final int CODE_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_11 = 4211;
  public static final String LIB_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_11 = "Liquidateur de la société";
  public static final int CODE_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_12 = 4212;
  public static final String LIB_ECHEC_ACTIVITE_HORS_CHAMPS_A_NOTIFIER_12 = "Membre du conseil de surveillance";
  public static final int CODE_ECHEC_AFFI_INSUFFISANTE_ORIGINE_DEL = 721;
  public static final String LIB_ECHEC_AFFI_INSUFFISANTE_ORIGINE_DEL = "Affiliation insuffisante AA13 5a origine dél";
  public static final int CODE_ECHEC_AFFI_INSUFFISANTE_ORIGINE_CP = 722;
  public static final String LIB_ECHEC_AFFI_INSUFFISANTE_ORIGINE_CP = "Affiliation insuffisante AA13 5a origine CP";
  public static final int ECHEC_CAPREV_MONTANT_REVISE = 182;
  public static final String LIB_ECHEC_CAPREV_MONTANT_REVISE = "Condition Montant Révisé non remplie";
  private static Map<BigDecimal, String> libelleMotifEchecANotifier;
  private static Map<BigDecimal, String> libelleMotifEchecANotifierGenerique;
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP00 = "Attribution hors Indemnisation";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP01 = "Recherche effective d'emploi";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP02 = "Aptitude physique";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP04_1 = "Activités dans le champ";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP04_2 = "Fait générateur de droit";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP04_3 = "Délai de forclusion";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP04_4 = "Délai de forclusion allongé";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP04_5 = "Absence activité en France";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP04_6 = "Fait générateur de droit hors délai";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP05 = "Chômage total";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP06 = "Age maximum";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP07 = "Affiliation";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP09 = "Chômage involontaire";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP12 = "Cumul avec une activité conservée";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP17 = "APE - TP";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP18 = "Montant non nul";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAPREV = "Montant révisé";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAPDUREENONNULLE_ASR = "Examen à fin ASR";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAPDUREENONNULLE_ATP = "Examen à fin ATP";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAPDUREENONNULLE_ASP = "Examen à fin ASP";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP14_01 = "Nombre de droits AFD";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP14_02 = "Condition bénéfice autre produit";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP21 = "Nombre de jour dans suspension";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP27 = "Validité du reliquat";
  public static final String LIB_RUBRIQUE_MOTIF_ECHEC_CAP26 = "Ancienneté";
  private static Map<BigDecimal, String> libelleRubriqueEchecCap;
  public static final Integer CODE_ECHEC_AFFI_INSUFFISANTE_RG;
  public static final Integer CODE_ECHEC_AFFI_INSUFFISANTE_A1;
  public static final Integer CODE_ECHEC_AFFI_INSUFFISANTE_A2A;
  public static final Integer CODE_ECHEC_AFFI_INSUFFISANTE_A2B;
  public static final Integer CODE_ECHEC_AFFI_INSUFFISANTE_A3;
  public static final Integer CODE_ECHEC_AFFI_INSUFFISANTE_A4;
  public static final Integer CODE_ECHEC_AFFI_INSUFFISANTE_A5;
  public static final Integer CODE_ECHEC_AFFI_INSUFFISANTE_A6;
  public static final Integer CODE_ECHEC_AFFI_INSUFFISANTE_A7;
  public static final Integer CODE_ECHEC_AFFI_INSUFFISANTE_A8;
  public static final Integer CODE_ECHEC_AFFI_INSUFFISANTE_A9A;
  public static final Integer CODE_ECHEC_AFFI_INSUFFISANTE_A9B;
  public static final Integer CODE_ECHEC_AFFI_INSUFFISANTE_A10;
  public static final Integer CODE_ECHEC_AFFI_INSUFFISANTE_A11;
  public static Map<String, Integer> s_codeMotifRejetAffi;
  
  public static String getLibelleMotifEchecANotifierSansParametre(BigDecimal codeEchec)
  {
    String retour = null;
    retour = (String)libelleMotifEchecANotifierGenerique.get(codeEchec);
    if (retour == null) {
      retour = (String)libelleMotifEchecANotifier.get(codeEchec);
    }
    return retour;
  }
  
  static
  {
    libelleEchecCap.put(new BigDecimal(0), "");
    libelleEchecCap.put(new BigDecimal(11), "Absence d'IDE ou chomage attesté");
    libelleEchecCap.put(new BigDecimal(21), "Aptitude physique non remplie");
    libelleEchecCap.put(new BigDecimal(41), "Absence de fait générateur de droit");
    libelleEchecCap.put(new BigDecimal(42), "Activité hors champ");
    libelleEchecCap.put(new BigDecimal(43), "Contrat de travail non rompu");
    libelleEchecCap.put(new BigDecimal(44), "Absence de FCT dans le délai de forclusion");
    libelleEchecCap.put(new BigDecimal(45), "Absence de FCT dans le delai de forclusion allongé");
    
    libelleEchecCap.put(new BigDecimal(46), "Fait générateur de droit non attesté");
    libelleEchecCap.put(new BigDecimal(47), "Absence d'activité en France");
    
    libelleEchecCap.put(new BigDecimal(49), "La FCT n'est pas incluse dans les deux mois précédents la fin de droit ARE");
    libelleEchecCap.put(new BigDecimal(51), "Présence d'une activité conservée");
    libelleEchecCap.put(new BigDecimal(61), "Le DE a plus de %0");
    libelleEchecCap.put(new BigDecimal(62), "le DE a plus de %0 et plus de %1 trimestres");
    
    libelleEchecCap.put(new BigDecimal(625), "Le demandeur est titulaire d'une retraite anticipée");
    libelleEchecCap.put(new BigDecimal(63), "Condition âge non remplie et retraite liquidée");
    libelleEchecCap.put(new BigDecimal(64), "Titulaire pension CAN et raccordement");
    libelleEchecCap.put(new BigDecimal(71), "Durée affiliation insuffisante");
    libelleEchecCap.put(new BigDecimal(91), "Départ volontaire motif non légitime");
    libelleEchecCap.put(new BigDecimal(92), "Départ volontaire motif non légitime suivi d'une activité insuffisante");
    
    libelleEchecCap.put(new BigDecimal(93), "Examen au 121e jour apres départ volontaire motif non légitime");
    
    libelleEchecCap.put(new BigDecimal(94), "Période de disponibilité/suspension volontaire");
    
    libelleEchecCap.put(new BigDecimal(121), "Activité conservée superieure aux seuils");
    
    libelleEchecCap.put(new BigDecimal(122), "Même employeur pour l'activité perdue et conservée");
    libelleEchecCap.put(new BigDecimal(123), "L'ANS ayant ouvert l'ARCE est toujours en cours");
    libelleEchecCap.put(new BigDecimal(97), "Nombre de droits AFD trop grand pour une filière courte");
    libelleEchecCap.put(new BigDecimal(98), "Nombre de droits AFD trop grand pour une filière intermédiaire");
    libelleEchecCap.put(new BigDecimal(99), "Nombre de droits AFD trop grand pour une filière longue");
    libelleEchecCap.put(new BigDecimal(141), "Absence de rejet clause de rattrapage");
    libelleEchecCap.put(new BigDecimal(171), "Complément de Libre Choix d'activité à taux plein a la date d'OD");
    libelleEchecCap.put(new BigDecimal(172), "Complément de Libre Choix d'activité à taux partiel a la date d'OD");
    libelleEchecCap.put(new BigDecimal(181), "Condition de cumul non remplie");
    libelleEchecCap.put(new BigDecimal(201), "Avis IPR défavorable");
    libelleEchecCap.put(new BigDecimal(202), "Condition des %0 jours de suspension non remplie");
    libelleEchecCap.put(new BigDecimal(271), "Reliquat de droit épuisé depuis le %0");
    libelleEchecCap.put(new BigDecimal(272), "Reliquat de droit déchu depuis le %0");
    libelleEchecCap.put(new BigDecimal(273), "Reliquat de droit éteint depuis le %0");
    libelleEchecCap.put(new BigDecimal(801), "Absence de reliquat ARE suite à fin ASR");
    libelleEchecCap.put(new BigDecimal(802), "Absence de reliquat ARE suite à fin ATP");
    libelleEchecCap.put(new BigDecimal(803), "Absence de reliquat ARE suite à fin ASP");
    libelleEchecCap.put(new BigDecimal(300), "Durée affiliation insuffisante");
    libelleEchecCap.put(new BigDecimal(261), "Condition ancienneté non remplie");
    
    libelleMotifEchecANotifier = new HashMap();
    
    libelleMotifEchecANotifier.put(new BigDecimal(11), "Absence d'IDE ou chomage attesté");
    libelleMotifEchecANotifier.put(new BigDecimal(21), "Aptitude physique non remplie");
    libelleMotifEchecANotifier.put(new BigDecimal(41), "Absence de fait générateur de droit");
    libelleMotifEchecANotifier.put(new BigDecimal(42), "Activité hors champ");
    libelleMotifEchecANotifier.put(new BigDecimal(421), "Statut de conjoint salarié");
    libelleMotifEchecANotifier.put(new BigDecimal(422), "Gérant majoritaire");
    libelleMotifEchecANotifier.put(new BigDecimal(423), "Gérant égalitaire");
    libelleMotifEchecANotifier.put(new BigDecimal(424), "Gérant de société");
    libelleMotifEchecANotifier.put(new BigDecimal(425), "Associé égalitaire");
    libelleMotifEchecANotifier.put(new BigDecimal(426), "Gérant associé de la société");
    libelleMotifEchecANotifier.put(new BigDecimal(427), "Gérant commandité de la société");
    libelleMotifEchecANotifier.put(new BigDecimal(428), "Président directeur général");
    libelleMotifEchecANotifier.put(new BigDecimal(429), "Directeur général administrateur");
    libelleMotifEchecANotifier.put(new BigDecimal(4210), "Directeur général non administrateur");
    libelleMotifEchecANotifier.put(new BigDecimal(4211), "Liquidateur de la société");
    libelleMotifEchecANotifier.put(new BigDecimal(4212), "Membre du conseil de surveillance");
    libelleMotifEchecANotifier.put(new BigDecimal(43), "Contrat de travail non rompu");
    libelleMotifEchecANotifier.put(new BigDecimal(44), "Absence de FCT dans le délai de forclusion");
    libelleMotifEchecANotifier.put(new BigDecimal(45), "Absence de FCT dans le delai de forclusion allongé");
    libelleMotifEchecANotifier.put(new BigDecimal(46), "Fait générateur de droit non attesté");
    libelleMotifEchecANotifier.put(new BigDecimal(47), "Absence d'activité en France");
    
    libelleMotifEchecANotifier.put(new BigDecimal(49), "La FCT n'est pas incluse dans les deux mois précédents la fin de droit ARE");
    
    libelleMotifEchecANotifier.put(new BigDecimal(51), "Présence d'une activité conservée");
    libelleMotifEchecANotifier.put(new BigDecimal(61), "Le DE a plus de %0");
    libelleMotifEchecANotifier.put(new BigDecimal(62), "le DE a plus de %0 et plus de %1 trimestres");
    
    libelleMotifEchecANotifier.put(new BigDecimal(625), "Le demandeur est titulaire d'une retraite anticipée");
    libelleMotifEchecANotifier.put(new BigDecimal(63), "Condition âge non remplie et retraite liquidée");
    libelleMotifEchecANotifier.put(new BigDecimal(64), "Titulaire pension CAN et raccordement");
    libelleMotifEchecANotifier.put(new BigDecimal(71), "Durée affiliation insuffisante");
    libelleMotifEchecANotifier.put(new BigDecimal(721), "Affiliation insuffisante AA13 5a origine dél");
    libelleMotifEchecANotifier.put(new BigDecimal(722), "Affiliation insuffisante AA13 5a origine CP");
    libelleMotifEchecANotifier.put(new BigDecimal(91), "Départ volontaire motif non légitime");
    libelleMotifEchecANotifier.put(new BigDecimal(92), "Départ volontaire motif non légitime suivi d'une activité insuffisante");
    
    libelleMotifEchecANotifier.put(new BigDecimal(93), "Examen au 121e jour apres départ volontaire motif non légitime");
    
    libelleMotifEchecANotifier.put(new BigDecimal(94), "Période de disponibilité/suspension volontaire");
    
    libelleMotifEchecANotifier.put(new BigDecimal(121), "Activité conservée superieure aux seuils");
    
    libelleMotifEchecANotifier.put(new BigDecimal(122), "Même employeur pour l'activité perdue et conservée");
    
    libelleMotifEchecANotifier.put(new BigDecimal(123), "L'ANS ayant ouvert l'ARCE est toujours en cours");
    
    libelleMotifEchecANotifier.put(new BigDecimal(171), "Complément de Libre Choix d'activité à taux plein a la date d'OD");
    libelleMotifEchecANotifier.put(new BigDecimal(172), "Complément de Libre Choix d'activité à taux partiel a la date d'OD");
    libelleMotifEchecANotifier.put(new BigDecimal(181), "Condition de cumul non remplie");
    libelleMotifEchecANotifier.put(new BigDecimal(201), "Avis IPR défavorable");
    libelleMotifEchecANotifier.put(new BigDecimal(202), "Condition des %0 jours de suspension non remplie");
    libelleMotifEchecANotifier.put(new BigDecimal(271), "Reliquat de droit épuisé depuis le %0");
    libelleMotifEchecANotifier.put(new BigDecimal(272), "Reliquat de droit déchu depuis le %0");
    libelleMotifEchecANotifier.put(new BigDecimal(273), "Reliquat de droit éteint depuis le %0");
    libelleMotifEchecANotifier.put(new BigDecimal(182), "Condition Montant Révisé non remplie");
    libelleMotifEchecANotifier.put(new BigDecimal(801), "Absence de reliquat ARE suite à fin ASR");
    libelleMotifEchecANotifier.put(new BigDecimal(802), "Absence de reliquat ARE suite à fin ATP");
    libelleMotifEchecANotifier.put(new BigDecimal(803), "Absence de reliquat ARE suite à fin ASP");
    libelleMotifEchecANotifier.put(new BigDecimal(97), "Nombre de droits AFD trop grand pour une filière courte");
    libelleMotifEchecANotifier.put(new BigDecimal(98), "Nombre de droits AFD trop grand pour une filière intermédiaire");
    libelleMotifEchecANotifier.put(new BigDecimal(99), "Nombre de droits AFD trop grand pour une filière longue");
    libelleMotifEchecANotifier.put(new BigDecimal(141), "Absence de rejet clause de rattrapage");
    libelleMotifEchecANotifier.put(new BigDecimal(300), "Durée affiliation insuffisante");
    libelleMotifEchecANotifier.put(new BigDecimal(261), "Condition ancienneté non remplie");
    
    libelleMotifEchecANotifierGenerique = new HashMap();
    
    libelleMotifEchecANotifierGenerique.put(new BigDecimal(62), "Condition age non remplie");
    libelleMotifEchecANotifierGenerique.put(new BigDecimal(625), "Condition age non remplie");
    libelleMotifEchecANotifierGenerique.put(new BigDecimal(61), "Condition age non remplie");
    libelleMotifEchecANotifierGenerique.put(new BigDecimal(202), "Condition des jours de suspension non remplie");
    libelleMotifEchecANotifierGenerique.put(new BigDecimal(272), "Reliquat de droit déchu");
    libelleMotifEchecANotifierGenerique.put(new BigDecimal(273), "Reliquat de droit éteint");
    libelleMotifEchecANotifierGenerique.put(new BigDecimal(271), "Reliquat de droit épuisé");
    
    libelleRubriqueEchecCap = new HashMap();
    
    libelleRubriqueEchecCap.put(new BigDecimal(11), "Recherche effective d'emploi");
    libelleRubriqueEchecCap.put(new BigDecimal(21), "Aptitude physique");
    libelleRubriqueEchecCap.put(new BigDecimal(41), "Fait générateur de droit");
    libelleRubriqueEchecCap.put(new BigDecimal(42), "Activités dans le champ");
    libelleRubriqueEchecCap.put(new BigDecimal(43), "Fait générateur de droit");
    libelleRubriqueEchecCap.put(new BigDecimal(44), "Délai de forclusion");
    libelleRubriqueEchecCap.put(new BigDecimal(45), "Délai de forclusion allongé");
    libelleRubriqueEchecCap.put(new BigDecimal(46), "Fait générateur de droit");
    libelleRubriqueEchecCap.put(new BigDecimal(47), "Absence activité en France");
    
    libelleRubriqueEchecCap.put(new BigDecimal(49), "Fait générateur de droit hors délai");
    libelleRubriqueEchecCap.put(new BigDecimal(51), "Chômage total");
    libelleRubriqueEchecCap.put(new BigDecimal(61), "Age maximum");
    libelleRubriqueEchecCap.put(new BigDecimal(62), "Age maximum");
    libelleRubriqueEchecCap.put(new BigDecimal(625), "Age maximum");
    libelleRubriqueEchecCap.put(new BigDecimal(63), "Age maximum");
    libelleRubriqueEchecCap.put(new BigDecimal(64), "Age maximum");
    libelleRubriqueEchecCap.put(new BigDecimal(71), "Affiliation");
    libelleRubriqueEchecCap.put(new BigDecimal(91), "Chômage involontaire");
    libelleRubriqueEchecCap.put(new BigDecimal(92), "Chômage involontaire");
    libelleRubriqueEchecCap.put(new BigDecimal(93), "Chômage involontaire");
    libelleRubriqueEchecCap.put(new BigDecimal(94), "Chômage involontaire");
    libelleRubriqueEchecCap.put(new BigDecimal(121), "Cumul avec une activité conservée");
    libelleRubriqueEchecCap.put(new BigDecimal(122), "Cumul avec une activité conservée");
    libelleRubriqueEchecCap.put(new BigDecimal(123), "Cumul avec une activité conservée");
    libelleRubriqueEchecCap.put(new BigDecimal(171), "APE - TP");
    libelleRubriqueEchecCap.put(new BigDecimal(172), "APE - TP");
    libelleRubriqueEchecCap.put(new BigDecimal(181), "Montant non nul");
    libelleRubriqueEchecCap.put(new BigDecimal(182), "Montant révisé");
    libelleRubriqueEchecCap.put(new BigDecimal(201), "Avis IPR défavorable");
    libelleRubriqueEchecCap.put(new BigDecimal(271), "Validité du reliquat");
    libelleRubriqueEchecCap.put(new BigDecimal(272), "Validité du reliquat");
    libelleRubriqueEchecCap.put(new BigDecimal(273), "Validité du reliquat");
    libelleRubriqueEchecCap.put(new BigDecimal(801), "Examen à fin ASR");
    libelleRubriqueEchecCap.put(new BigDecimal(802), "Examen à fin ATP");
    libelleRubriqueEchecCap.put(new BigDecimal(803), "Examen à fin ASP");
    libelleRubriqueEchecCap.put(new BigDecimal(97), "Nombre de droits AFD");
    libelleRubriqueEchecCap.put(new BigDecimal(98), "Nombre de droits AFD");
    libelleRubriqueEchecCap.put(new BigDecimal(99), "Nombre de droits AFD");
    libelleRubriqueEchecCap.put(new BigDecimal(141), "Condition bénéfice autre produit");
    libelleRubriqueEchecCap.put(new BigDecimal(300), "Durée affiliation insuffisante");
    libelleRubriqueEchecCap.put(new BigDecimal(202), "Nombre de jour dans suspension");
    libelleRubriqueEchecCap.put(new BigDecimal(261), "Ancienneté");
    
    CODE_ECHEC_AFFI_INSUFFISANTE_RG = Integer.valueOf(7100);
    CODE_ECHEC_AFFI_INSUFFISANTE_A1 = Integer.valueOf(7101);
    CODE_ECHEC_AFFI_INSUFFISANTE_A2A = Integer.valueOf(7112);
    CODE_ECHEC_AFFI_INSUFFISANTE_A2B = Integer.valueOf(7113);
    CODE_ECHEC_AFFI_INSUFFISANTE_A3 = Integer.valueOf(7103);
    CODE_ECHEC_AFFI_INSUFFISANTE_A4 = Integer.valueOf(7104);
    CODE_ECHEC_AFFI_INSUFFISANTE_A5 = Integer.valueOf(7105);
    CODE_ECHEC_AFFI_INSUFFISANTE_A6 = Integer.valueOf(7106);
    CODE_ECHEC_AFFI_INSUFFISANTE_A7 = Integer.valueOf(7107);
    CODE_ECHEC_AFFI_INSUFFISANTE_A8 = Integer.valueOf(7108);
    CODE_ECHEC_AFFI_INSUFFISANTE_A9A = Integer.valueOf(7114);
    CODE_ECHEC_AFFI_INSUFFISANTE_A9B = Integer.valueOf(7115);
    CODE_ECHEC_AFFI_INSUFFISANTE_A10 = Integer.valueOf(7110);
    CODE_ECHEC_AFFI_INSUFFISANTE_A11 = Integer.valueOf(7111);
    
    s_codeMotifRejetAffi = new HashMap();
    
    s_codeMotifRejetAffi.put("RG", CODE_ECHEC_AFFI_INSUFFISANTE_RG);
    s_codeMotifRejetAffi.put("RGP", CODE_ECHEC_AFFI_INSUFFISANTE_RG);
    s_codeMotifRejetAffi.put("OP", CODE_ECHEC_AFFI_INSUFFISANTE_RG);
    s_codeMotifRejetAffi.put("A1", CODE_ECHEC_AFFI_INSUFFISANTE_A1);
    s_codeMotifRejetAffi.put("A2a", CODE_ECHEC_AFFI_INSUFFISANTE_A2A);
    s_codeMotifRejetAffi.put("A2b", CODE_ECHEC_AFFI_INSUFFISANTE_A2B);
    s_codeMotifRejetAffi.put("A3", CODE_ECHEC_AFFI_INSUFFISANTE_A3);
    s_codeMotifRejetAffi.put("A4", CODE_ECHEC_AFFI_INSUFFISANTE_A4);
    s_codeMotifRejetAffi.put("A5", CODE_ECHEC_AFFI_INSUFFISANTE_A5);
    s_codeMotifRejetAffi.put("A6", CODE_ECHEC_AFFI_INSUFFISANTE_A6);
    s_codeMotifRejetAffi.put("A7", CODE_ECHEC_AFFI_INSUFFISANTE_A7);
    s_codeMotifRejetAffi.put("A8", CODE_ECHEC_AFFI_INSUFFISANTE_A8);
    s_codeMotifRejetAffi.put("A9A", CODE_ECHEC_AFFI_INSUFFISANTE_A9A);
    s_codeMotifRejetAffi.put("A9B", CODE_ECHEC_AFFI_INSUFFISANTE_A9B);
    s_codeMotifRejetAffi.put("A10", CODE_ECHEC_AFFI_INSUFFISANTE_A10);
    s_codeMotifRejetAffi.put("A11", CODE_ECHEC_AFFI_INSUFFISANTE_A11);
  }
  
  public static Map<BigDecimal, String> getLibelleEchecCap()
  {
    return libelleEchecCap;
  }
  
  public static Map<BigDecimal, String> getLibelleMotifEchecANotifier()
  {
    return libelleMotifEchecANotifier;
  }
  
  public static Map<BigDecimal, String> getLibelleMotifEchecANotifierGenerique()
  {
    return libelleMotifEchecANotifierGenerique;
  }
  
  public static Map<BigDecimal, String> getLibelleRubriqueEchecCap()
  {
    return libelleRubriqueEchecCap;
  }
}

/* Location:
 * Qualified Name:     CodesMotifsEchec
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */